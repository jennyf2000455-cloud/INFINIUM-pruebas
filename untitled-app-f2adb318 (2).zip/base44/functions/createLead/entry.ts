import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const data = await req.json();

    const lead = await base44.asServiceRole.entities.Lead.create(data);

    // Llamada existente que ya tenías
    await base44.asServiceRole.functions.invoke('notifyLead', data).catch(() => {});

    // Ping al agente externo (await para que Deno no corte la conexión antes de que termine)
    await fetch("https://ivory-shine-cleaning.base44.app/api/functions/notifyLeadPublic", {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "x-api-key": "public"
      },
      body: JSON.stringify({ lead: data }),
    }).catch(() => {});

    return Response.json({ success: true, lead });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});