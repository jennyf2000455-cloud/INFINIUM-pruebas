Deno.serve(async (req) => {
  const cors = { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' };
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
  try {
    const body = await req.json().catch(() => ({}));
    const res = await fetch('https://ivory-shine-cleaning.base44.app/api/apps/69f4e671caaf925632125ab5/functions/notifyLeadPublic', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const data = await res.json().catch(() => ({}));
    return new Response(JSON.stringify(data), { status: res.status, headers: cors });
  } catch(err) {
    return new Response(JSON.stringify({ error: String(err) }), { status: 500, headers: cors });
  }
});