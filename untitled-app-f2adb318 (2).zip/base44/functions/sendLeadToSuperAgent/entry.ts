Deno.serve(async (req) => {
  try {
    const payload = await req.json();
    const lead = payload.data || payload.entity || payload;

    console.log("Lead recibido:", JSON.stringify(lead));

    const body = {
      full_name: lead.full_name || lead.name || "",
      email: lead.email || "",
      phone: lead.phone || "",
      cleaning_type: lead.cleaning_type || lead.service_type || "",
      address_zip: lead.address_zip || lead.zip || "",
      notes: lead.notes || ""
    };

    console.log("Enviando al superagente:", JSON.stringify(body));

    const response = await fetch("https://api.base44.com/api/apps/69f4e671caaf925632125ab5/functions/notifyLeadPublic", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });

    const result = await response.text();
    console.log("Respuesta superagente:", response.status, result);

    return Response.json({ success: true, status: response.status, result });
  } catch (error) {
    console.error("Error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});