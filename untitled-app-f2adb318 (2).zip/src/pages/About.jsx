export default function About() {
  return (
    <div style={{ fontFamily: "'Georgia', serif", background: "#FAFAF7", minHeight: "100vh", padding: "60px 24px" }}>
      <div style={{ maxWidth: 800, margin: "0 auto" }}>
        <h1 style={{ fontSize: "clamp(28px, 5vw, 48px)", fontWeight: 300, letterSpacing: "0.02em", color: "#1A1A1A", marginBottom: 24 }}>
          About Ivory Shine Cleaning
        </h1>
        <div style={{ width: 60, height: 2, background: "#C8A44D", marginBottom: 32 }} />
        <div style={{ fontSize: 16, lineHeight: 1.9, color: "#4B5563" }}>
          <p style={{ marginBottom: 20 }}>
            Ivory Shine Cleaning LLC is a professional residential and commercial cleaning company proudly serving Virginia, USA. With over 10 years of hands-on experience, we are dedicated to delivering spotless results and exceptional service to every client we serve.
          </p>
          <p style={{ marginBottom: 20 }}>
            This platform was built to make booking a cleaning service as simple and stress-free as possible. Whether you need a regular home cleaning, a deep clean, a move-in/move-out service, or commercial office cleaning, our smart assistant IVY guides you through a quick 3-question process to understand your needs and get you scheduled fast.
          </p>
          <p style={{ marginBottom: 20 }}>
            We serve homeowners, renters, property managers, and small business owners who value their time and expect a high standard of cleanliness. Our Detail-Clean Rotation System® ensures that recurring clients receive consistent, thorough service on every visit — not just the first one.
          </p>
          <p style={{ marginBottom: 20 }}>
            Ivory Shine Cleaning was founded on the values of reliability, respect, and excellence. Every home and office we clean is treated with the same care and attention we would give our own. We are bilingual (English & Spanish) and committed to making every client feel heard and valued.
          </p>
          <p>
            Built and managed by the Ivory Shine Cleaning team in Virginia. For questions, bookings, or a free quote, visit our home page or reach out via our Contact page.
          </p>
        </div>
        <div style={{ marginTop: 40 }}>
          <a href="/Home" style={{ display: "inline-block", background: "#2D5A27", color: "#fff", textDecoration: "none", borderRadius: 10, padding: "13px 28px", fontSize: 14, fontWeight: 600, marginRight: 12 }}>
            ← Back to Home
          </a>
          <a href="/Contact" style={{ display: "inline-block", background: "transparent", color: "#2D5A27", textDecoration: "none", borderRadius: 10, padding: "13px 28px", fontSize: 14, fontWeight: 600, border: "1.5px solid #2D5A27" }}>
            Contact Us →
          </a>
        </div>
      </div>
    </div>
  );
}