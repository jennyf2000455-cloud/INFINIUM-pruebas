import { useState, useEffect } from "react";
import { Lead } from "@/api/entities";

const COLORS = {
  gold: "#C8A44D",
  olive: "#7A8C5E",
  white: "#FFFFFF",
  ivory: "#FAFAF7",
  dark: "#1A1A1A",
  green: "#2D5A27",
  gray: "#6B7280",
  lightGray: "#F5F5F0",
};

const LOGO = "https://media.base44.com/images/public/69f4e671caaf925632125ab5/7a4dde46d_logooficial.png";
const ADMIN_PASSWORD = "IvoryShine2025!";

const STATUS_COLORS = {
  "New": { bg: "#EFF6FF", text: "#1D4ED8", border: "#BFDBFE" },
  "Contacted": { bg: "#FFF7ED", text: "#C2410C", border: "#FED7AA" },
  "Appointment Requested": { bg: "#F0FDF4", text: "#166534", border: "#BBF7D0" },
  "Scheduled": { bg: "#FDF4FF", text: "#7E22CE", border: "#E9D5FF" },
  "Quote Sent": { bg: "#FFFBEB", text: "#B45309", border: "#FDE68A" },
  "Completed": { bg: "#ECFDF5", text: "#065F46", border: "#6EE7B7" },
  "Lost": { bg: "#FFF1F2", text: "#BE123C", border: "#FECDD3" },
};

const ALL_STATUSES = ["New", "Contacted", "Appointment Requested", "Scheduled", "Quote Sent", "Completed", "Lost"];

export default function Admin() {
  const [authed, setAuthed] = useState(false);
  const [password, setPassword] = useState("");
  const [pwError, setPwError] = useState(false);
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [filterStatus, setFilterStatus] = useState("All");
  const [selectedLead, setSelectedLead] = useState(null);
  const [updatingId, setUpdatingId] = useState(null);
  const [searchQ, setSearchQ] = useState("");
  const [adminNote, setAdminNote] = useState("");
  const [savingNote, setSavingNote] = useState(false);
  const [sortField, setSortField] = useState("created_date");
  const [sortDir, setSortDir] = useState("desc");

  const handleLogin = (e) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setAuthed(true);
    } else {
      setPwError(true);
    }
  };

  useEffect(() => {
    if (authed) loadData();
  }, [authed]);

  const loadData = async () => {
    setLoading(true);
    try {
      const leadsData = await Lead.list();
      setLeads(leadsData.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)));
    } catch (err) {
      console.error("Error loading leads:", err);
    }
    setLoading(false);
  };

  const updateLeadStatus = async (leadId, newStatus) => {
    setUpdatingId(leadId);
    try {
      await Lead.update(leadId, { status: newStatus });
      setLeads((prev) => prev.map((l) => l.id === leadId ? { ...l, status: newStatus } : l));
      if (selectedLead?.id === leadId) setSelectedLead((prev) => ({ ...prev, status: newStatus }));
    } catch (err) {
      console.error("Error updating status:", err);
    }
    setUpdatingId(null);
  };

  const saveAdminNote = async () => {
    if (!selectedLead || !adminNote.trim()) return;
    setSavingNote(true);
    try {
      const existingNotes = selectedLead.notes || "";
      const timestamp = new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
      const combined = existingNotes
        ? `${existingNotes}\n\n[Admin ${timestamp}]: ${adminNote.trim()}`
        : `[Admin ${timestamp}]: ${adminNote.trim()}`;
      await Lead.update(selectedLead.id, { notes: combined });
      setLeads((prev) => prev.map((l) => l.id === selectedLead.id ? { ...l, notes: combined } : l));
      setSelectedLead((prev) => ({ ...prev, notes: combined }));
      setAdminNote("");
    } catch (err) {
      console.error("Error saving note:", err);
    }
    setSavingNote(false);
  };

  const filteredLeads = leads
    .filter((l) => filterStatus === "All" || l.status === filterStatus)
    .filter((l) => {
      if (!searchQ) return true;
      const q = searchQ.toLowerCase();
      return [l.full_name, l.phone, l.email, l.cleaning_type, l.address_zip, l.space_size, l.notes]
        .some((v) => v?.toLowerCase().includes(q));
    });

  const stats = {
    total: leads.length,
    newLeads: leads.filter((l) => l.status === "New").length,
    contacted: leads.filter((l) => l.status === "Contacted").length,
    requested: leads.filter((l) => l.status === "Appointment Requested").length,
    scheduled: leads.filter((l) => l.status === "Scheduled").length,
    completed: leads.filter((l) => l.status === "Completed").length,
    lost: leads.filter((l) => l.status === "Lost").length,
  };

  const formatDate = (d) => {
    if (!d) return "—";
    return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" });
  };

  const formatShortDate = (d) => {
    if (!d) return "—";
    return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  };

  // Login screen
  if (!authed) {
    return (
      <div style={{ minHeight: "100vh", background: `linear-gradient(135deg, ${COLORS.dark} 0%, #1A2A1A 100%)`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Georgia', serif", padding: 24 }}>
        <div style={{ background: COLORS.white, borderRadius: 20, padding: "44px 36px", width: "100%", maxWidth: 400, boxShadow: "0 20px 60px rgba(0,0,0,0.4)", textAlign: "center" }}>
          <img src={LOGO} alt="Ivory Shine" style={{ height: 60, marginBottom: 20, objectFit: "contain" }} />
          <div style={{ width: 48, height: 48, borderRadius: "50%", background: COLORS.gold + "20", border: `2px solid ${COLORS.gold}50`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, margin: "0 auto 18px" }}>🔒</div>
          <h2 style={{ fontSize: 20, fontWeight: 700, margin: "0 0 5px", color: COLORS.dark }}>Admin Access</h2>
          <p style={{ color: COLORS.gray, fontSize: 13, marginBottom: 24 }}>Ivory Shine Cleaning — Private CRM</p>
          <form onSubmit={handleLogin}>
            <input
              type="password"
              placeholder="Enter admin password"
              value={password}
              onChange={(e) => { setPassword(e.target.value); setPwError(false); }}
              style={{ width: "100%", padding: "13px 15px", border: `1.5px solid ${pwError ? "#EF4444" : "#DDD"}`, borderRadius: 10, fontSize: 14, fontFamily: "inherit", outline: "none", marginBottom: 8, boxSizing: "border-box" }}
              autoFocus
            />
            {pwError && <p style={{ color: "#EF4444", fontSize: 12, margin: "0 0 10px", textAlign: "left" }}>⚠️ Incorrect password. Try again.</p>}
            <button type="submit" style={{ width: "100%", background: COLORS.dark, color: COLORS.white, border: "none", borderRadius: 10, padding: "13px", fontSize: 14, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", marginTop: 4 }}>
              Enter CRM →
            </button>
          </form>
          <p style={{ fontSize: 11, color: "#BBB", marginTop: 18 }}>🔒 Private admin access only</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: COLORS.lightGray, fontFamily: "'Georgia', serif" }}>
      <style>{`
        * { box-sizing: border-box; }
        @media (max-width: 768px) {
          .crm-sidebar { display: none !important; }
          .crm-detail { position: fixed !important; top: 0; left: 0; right: 0; bottom: 0; z-index: 50; overflow-y: auto; }
        }
      `}</style>

      {/* TOP NAV */}
      <div style={{ background: COLORS.dark, padding: "0 20px", height: 58, display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: `2px solid ${COLORS.gold}25`, position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <img src={LOGO} alt="Ivory Shine" style={{ height: 34, objectFit: "contain" }} />
          <div>
            <div style={{ color: COLORS.gold, fontSize: 12, fontWeight: 700, letterSpacing: "0.1em" }}>ADMIN CRM</div>
            <div style={{ color: "#555", fontSize: 9, letterSpacing: "0.06em" }}>PRIVATE — IVORY SHINE CLEANING LLC</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <div style={{ background: "#2A2A2A", borderRadius: 8, padding: "4px 12px", fontSize: 11, color: "#AAA" }}>
            {leads.length} leads total
          </div>
          <button onClick={loadData} style={{ background: "transparent", color: "#888", border: "1px solid #333", borderRadius: 8, padding: "5px 12px", cursor: "pointer", fontSize: 11, fontFamily: "inherit" }}>
            🔄 Refresh
          </button>
          <button onClick={() => setAuthed(false)} style={{ background: "transparent", color: "#555", border: "none", cursor: "pointer", fontSize: 11, fontFamily: "inherit" }}>
            Sign out
          </button>
        </div>
      </div>

      <div style={{ display: "flex", minHeight: "calc(100vh - 58px)" }}>
        {/* SIDEBAR */}
        <div className="crm-sidebar" style={{ width: 190, background: COLORS.white, borderRight: `1px solid #E8E4D8`, padding: "20px 0", flexShrink: 0 }}>
          {[
            { id: "dashboard", icon: "📊", label: "Dashboard" },
            { id: "leads", icon: "👥", label: "All Leads" },
            { id: "new_leads", icon: "🆕", label: `New (${stats.newLeads})` },
            { id: "scheduled", icon: "📅", label: `Scheduled (${stats.scheduled})` },
            { id: "completed", icon: "✅", label: `Completed (${stats.completed})` },
          ].map(({ id, icon, label }) => (
            <button key={id} onClick={() => {
              if (id === "new_leads") { setActiveTab("leads"); setFilterStatus("New"); }
              else if (id === "scheduled") { setActiveTab("leads"); setFilterStatus("Scheduled"); }
              else if (id === "completed") { setActiveTab("leads"); setFilterStatus("Completed"); }
              else { setActiveTab(id); setFilterStatus("All"); }
            }}
              style={{ width: "100%", background: (activeTab === id || (id === "new_leads" && activeTab === "leads" && filterStatus === "New") || (id === "scheduled" && activeTab === "leads" && filterStatus === "Scheduled") || (id === "completed" && activeTab === "leads" && filterStatus === "Completed")) ? COLORS.gold + "12" : "transparent", border: "none", borderLeft: "3px solid transparent", padding: "13px 18px", cursor: "pointer", textAlign: "left", fontSize: 13, color: COLORS.dark, fontFamily: "inherit", display: "flex", alignItems: "center", gap: 8 }}>
              {icon} {label}
            </button>
          ))}

          <div style={{ margin: "16px 14px", height: 1, background: "#EEE" }} />

          <div style={{ padding: "6px 18px" }}>
            <div style={{ fontSize: 10, color: "#BBB", letterSpacing: "0.08em", marginBottom: 10 }}>STATUS COUNTS</div>
            {ALL_STATUSES.map((s) => {
              const count = leads.filter((l) => l.status === s).length;
              if (count === 0) return null;
              return (
                <div key={s} onClick={() => { setActiveTab("leads"); setFilterStatus(s); }}
                  style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", fontSize: 12, color: COLORS.gray, cursor: "pointer", borderRadius: 4 }}>
                  <span>{s}</span>
                  <span style={{ fontWeight: 700, color: STATUS_COLORS[s]?.text || COLORS.dark }}>{count}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* MAIN CONTENT */}
        <div style={{ flex: 1, padding: "24px", overflow: "auto", minWidth: 0 }}>
          {loading && (
            <div style={{ textAlign: "center", padding: "60px 24px", color: COLORS.gray }}>
              <div style={{ fontSize: 32, marginBottom: 12 }}>⏳</div>
              Loading leads...
            </div>
          )}

          {/* DASHBOARD */}
          {!loading && activeTab === "dashboard" && (
            <div>
              <h2 style={{ fontSize: 20, fontWeight: 400, margin: "0 0 20px", letterSpacing: "0.02em" }}>📊 Dashboard Overview</h2>

              {/* Stat cards */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: 14, marginBottom: 28 }}>
                {[
                  { label: "Total Leads", value: stats.total, icon: "👥", color: COLORS.dark },
                  { label: "New", value: stats.newLeads, icon: "🆕", color: "#1D4ED8" },
                  { label: "Contacted", value: stats.contacted, icon: "📞", color: "#C2410C" },
                  { label: "Appt. Requested", value: stats.requested, icon: "📋", color: "#166534" },
                  { label: "Scheduled", value: stats.scheduled, icon: "📅", color: "#7E22CE" },
                  { label: "Completed", value: stats.completed, icon: "✅", color: "#065F46" },
                  { label: "Lost", value: stats.lost, icon: "❌", color: "#BE123C" },
                ].map(({ label, value, icon, color }) => (
                  <div key={label} style={{ background: COLORS.white, borderRadius: 12, padding: "18px 14px", border: `1px solid #E8E4D8`, textAlign: "center", cursor: "pointer" }}
                    onClick={() => { if (label !== "Total Leads") { setActiveTab("leads"); setFilterStatus(label === "Appt. Requested" ? "Appointment Requested" : label); } else { setActiveTab("leads"); setFilterStatus("All"); } }}>
                    <div style={{ fontSize: 22, marginBottom: 6 }}>{icon}</div>
                    <div style={{ fontSize: 26, fontWeight: 700, color, marginBottom: 3 }}>{value}</div>
                    <div style={{ fontSize: 11, color: COLORS.gray }}>{label}</div>
                  </div>
                ))}
              </div>

              {/* Conversion rate */}
              {stats.total > 0 && (
                <div style={{ background: COLORS.white, borderRadius: 14, padding: "20px 24px", border: `1px solid #E8E4D8`, marginBottom: 24 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.gray, marginBottom: 12 }}>PIPELINE OVERVIEW</div>
                  <div style={{ display: "flex", gap: 4, height: 10, borderRadius: 5, overflow: "hidden", marginBottom: 10 }}>
                    {ALL_STATUSES.map((s) => {
                      const count = leads.filter((l) => l.status === s).length;
                      const pct = (count / stats.total) * 100;
                      if (pct === 0) return null;
                      return <div key={s} style={{ width: `${pct}%`, background: STATUS_COLORS[s]?.text || "#888", transition: "width 0.3s" }} title={`${s}: ${count}`} />;
                    })}
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 12 }}>
                    {ALL_STATUSES.filter((s) => leads.filter((l) => l.status === s).length > 0).map((s) => (
                      <div key={s} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, color: COLORS.gray }}>
                        <div style={{ width: 8, height: 8, borderRadius: 2, background: STATUS_COLORS[s]?.text || "#888" }} />
                        {s} ({leads.filter((l) => l.status === s).length})
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recent leads */}
              <div style={{ background: COLORS.white, borderRadius: 14, border: `1px solid #E8E4D8`, overflow: "hidden" }}>
                <div style={{ padding: "14px 20px", borderBottom: "1px solid #F0EEE8", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <h3 style={{ margin: 0, fontSize: 14, fontWeight: 600 }}>Recent Leads</h3>
                  <button onClick={() => setActiveTab("leads")} style={{ background: "none", border: "none", color: COLORS.gold, cursor: "pointer", fontSize: 12, fontFamily: "inherit" }}>View all →</button>
                </div>
                {leads.length === 0 ? (
                  <div style={{ padding: "40px 24px", textAlign: "center", color: COLORS.gray, fontSize: 14 }}>
                    No leads yet — they'll appear here when clients submit the form.
                  </div>
                ) : leads.slice(0, 8).map((lead) => (
                  <div key={lead.id} onClick={() => { setSelectedLead(lead); setAdminNote(""); setActiveTab("leads"); }}
                    style={{ padding: "12px 20px", borderBottom: "1px solid #F8F7F2", display: "flex", alignItems: "center", gap: 14, cursor: "pointer" }}
                    onMouseEnter={(e) => e.currentTarget.style.background = COLORS.ivory}
                    onMouseLeave={(e) => e.currentTarget.style.background = COLORS.white}>
                    <div style={{ width: 34, height: 34, borderRadius: "50%", background: COLORS.gold + "20", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: COLORS.gold, flexShrink: 0 }}>
                      {(lead.full_name || "?")[0]?.toUpperCase()}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.dark, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{lead.full_name || "Unknown"}</div>
                      <div style={{ fontSize: 11, color: COLORS.gray }}>{lead.cleaning_type} · {lead.phone}</div>
                    </div>
                    <div style={{ textAlign: "right", flexShrink: 0 }}>
                      <span style={{ fontSize: 10, fontWeight: 600, letterSpacing: "0.04em", padding: "3px 9px", borderRadius: 20, background: STATUS_COLORS[lead.status]?.bg || "#F3F4F6", color: STATUS_COLORS[lead.status]?.text || "#374151", border: `1px solid ${STATUS_COLORS[lead.status]?.border || "#E5E7EB"}` }}>
                        {lead.status}
                      </span>
                      <div style={{ fontSize: 10, color: "#BBB", marginTop: 3 }}>{formatShortDate(lead.created_date)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* LEADS LIST */}
          {!loading && activeTab === "leads" && (
            <div>
              {/* Toolbar */}
              <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 18, flexWrap: "wrap" }}>
                <h2 style={{ fontSize: 18, fontWeight: 400, margin: 0, flex: 1 }}>
                  👥 {filterStatus === "All" ? "All Leads" : filterStatus} ({filteredLeads.length})
                </h2>
                <input
                  placeholder="Search name, phone, email, ZIP..."
                  value={searchQ}
                  onChange={(e) => setSearchQ(e.target.value)}
                  style={{ padding: "9px 13px", border: "1.5px solid #DDD", borderRadius: 9, fontSize: 12, fontFamily: "inherit", outline: "none", width: 220 }}
                />
                <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}
                  style={{ padding: "9px 13px", border: "1.5px solid #DDD", borderRadius: 9, fontSize: 12, fontFamily: "inherit", outline: "none", background: COLORS.white }}>
                  <option value="All">All Statuses</option>
                  {ALL_STATUSES.map((s) => <option key={s} value={s}>{s} ({leads.filter((l) => l.status === s).length})</option>)}
                </select>
                {(searchQ || filterStatus !== "All") && (
                  <button onClick={() => { setSearchQ(""); setFilterStatus("All"); }} style={{ background: "none", border: "1px solid #DDD", borderRadius: 8, padding: "8px 12px", cursor: "pointer", fontSize: 11, color: COLORS.gray, fontFamily: "inherit" }}>
                    ✕ Clear
                  </button>
                )}
              </div>

              <div style={{ display: "grid", gridTemplateColumns: selectedLead ? "minmax(0,1fr) 360px" : "1fr", gap: 18, alignItems: "start" }}>
                {/* Lead list */}
                <div style={{ background: COLORS.white, borderRadius: 14, border: `1px solid #E8E4D8`, overflow: "hidden" }}>
                  {filteredLeads.length === 0 ? (
                    <div style={{ padding: "50px 24px", textAlign: "center", color: COLORS.gray, fontSize: 14 }}>
                      {leads.length === 0 ? "No leads yet." : "No leads match your search."}
                    </div>
                  ) : filteredLeads.map((lead) => {
                    const isSelected = selectedLead?.id === lead.id;
                    return (
                      <div key={lead.id}
                        onClick={() => { setSelectedLead(isSelected ? null : lead); setAdminNote(""); }}
                        style={{ padding: "14px 18px", borderBottom: "1px solid #F8F7F2", cursor: "pointer", background: isSelected ? COLORS.gold + "08" : COLORS.white, borderLeft: isSelected ? `3px solid ${COLORS.gold}` : "3px solid transparent", transition: "all 0.1s" }}
                        onMouseEnter={(e) => { if (!isSelected) e.currentTarget.style.background = COLORS.ivory; }}
                        onMouseLeave={(e) => { if (!isSelected) e.currentTarget.style.background = COLORS.white; }}>
                        <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                          <div style={{ width: 38, height: 38, borderRadius: "50%", background: isSelected ? COLORS.gold + "30" : COLORS.gold + "18", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 700, color: COLORS.gold, flexShrink: 0 }}>
                            {(lead.full_name || "?")[0]?.toUpperCase()}
                          </div>
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}>
                              <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.dark }}>{lead.full_name || "Unknown"}</div>
                              <span style={{ fontSize: 10, fontWeight: 600, padding: "3px 9px", borderRadius: 20, background: STATUS_COLORS[lead.status]?.bg || "#F3F4F6", color: STATUS_COLORS[lead.status]?.text || "#374151", border: `1px solid ${STATUS_COLORS[lead.status]?.border || "#E5E7EB"}`, flexShrink: 0 }}>
                                {lead.status}
                              </span>
                            </div>
                            <div style={{ fontSize: 12, color: COLORS.gray, marginTop: 3 }}>{lead.phone}{lead.email && ` · ${lead.email}`}</div>
                            <div style={{ fontSize: 11, color: COLORS.gray, marginTop: 4, display: "flex", gap: 10, flexWrap: "wrap" }}>
                              {lead.cleaning_type && <span>🧹 {lead.cleaning_type}</span>}
                              {lead.space_size && <span>📐 {lead.space_size}</span>}
                              {lead.lead_source && <span>📡 {lead.lead_source}</span>}
                              {lead.preferred_date && <span>📅 {lead.preferred_date}</span>}
                            </div>
                            <div style={{ fontSize: 10, color: "#BBB", marginTop: 4 }}>{formatDate(lead.created_date)}</div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Lead Detail Panel */}
                {selectedLead && (
                  <div className="crm-detail" style={{ background: COLORS.white, borderRadius: 14, border: `1px solid #E8E4D8`, padding: "22px", position: "sticky", top: 80, maxHeight: "calc(100vh - 100px)", overflowY: "auto" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18 }}>
                      <div>
                        <div style={{ width: 46, height: 46, borderRadius: "50%", background: COLORS.gold + "20", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 700, color: COLORS.gold, marginBottom: 8 }}>
                          {(selectedLead.full_name || "?")[0]?.toUpperCase()}
                        </div>
                        <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: COLORS.dark }}>{selectedLead.full_name}</h3>
                        <div style={{ fontSize: 11, color: COLORS.gray, marginTop: 2 }}>Lead · {formatDate(selectedLead.created_date)}</div>
                      </div>
                      <button onClick={() => setSelectedLead(null)} style={{ background: COLORS.lightGray, border: "none", borderRadius: 8, color: COLORS.gray, cursor: "pointer", fontSize: 14, padding: "5px 10px" }}>✕</button>
                    </div>

                    {/* Status changer */}
                    <div style={{ marginBottom: 18 }}>
                      <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.gray, letterSpacing: "0.1em", marginBottom: 8 }}>CHANGE STATUS</div>
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                        {ALL_STATUSES.map((s) => (
                          <button key={s} onClick={() => updateLeadStatus(selectedLead.id, s)} disabled={updatingId === selectedLead.id}
                            style={{ padding: "5px 10px", borderRadius: 20, border: `1px solid ${STATUS_COLORS[s]?.border || "#E5E7EB"}`, background: selectedLead.status === s ? STATUS_COLORS[s]?.bg || "#F3F4F6" : COLORS.white, color: selectedLead.status === s ? STATUS_COLORS[s]?.text || "#374151" : COLORS.gray, cursor: updatingId ? "wait" : "pointer", fontSize: 10, fontWeight: selectedLead.status === s ? 700 : 400, fontFamily: "inherit", transition: "all 0.15s" }}>
                            {selectedLead.status === s ? "● " : ""}{s}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div style={{ height: 1, background: "#F0EEE8", margin: "14px 0" }} />

                    {/* Contact info */}
                    <div style={{ marginBottom: 14 }}>
                      <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.gray, letterSpacing: "0.1em", marginBottom: 10 }}>CONTACT INFO</div>
                      {[
                        ["📞", "Phone", selectedLead.phone, `tel:${selectedLead.phone}`],
                        ["✉️", "Email", selectedLead.email, `mailto:${selectedLead.email}`],
                      ].filter(([, , v]) => v).map(([icon, label, value, href]) => (
                        <div key={label} style={{ marginBottom: 8 }}>
                          <div style={{ fontSize: 10, color: COLORS.gray, marginBottom: 3 }}>{icon} {label}</div>
                          <a href={href} style={{ fontSize: 14, color: COLORS.dark, textDecoration: "none", display: "block", background: COLORS.lightGray, borderRadius: 8, padding: "8px 12px", fontWeight: 600 }}>
                            {value}
                          </a>
                        </div>
                      ))}
                    </div>

                    <div style={{ height: 1, background: "#F0EEE8", margin: "14px 0" }} />

                    {/* Cleaning details */}
                    <div style={{ marginBottom: 14 }}>
                      <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.gray, letterSpacing: "0.1em", marginBottom: 10 }}>CLEANING REQUEST</div>
                      {[
                        ["🧹", "Type", selectedLead.cleaning_type],
                        ["📐", "Space Size", selectedLead.space_size],
                        ["⏰", "Desired Schedule", selectedLead.desired_schedule],
                        ["📅", "Preferred Date", selectedLead.preferred_date],
                        ["🕐", "Preferred Time", selectedLead.preferred_time],
                        ["📍", "Address / ZIP", selectedLead.address_zip],
                        ["📡", "Lead Source", selectedLead.lead_source],
                      ].filter(([, , v]) => v).map(([icon, label, value]) => (
                        <div key={label} style={{ marginBottom: 8 }}>
                          <div style={{ fontSize: 10, color: COLORS.gray, marginBottom: 2 }}>{icon} {label}</div>
                          <div style={{ fontSize: 13, color: COLORS.dark, background: COLORS.lightGray, borderRadius: 8, padding: "7px 11px" }}>{value}</div>
                        </div>
                      ))}
                    </div>

                    {/* Notes */}
                    {selectedLead.notes && (
                      <>
                        <div style={{ height: 1, background: "#F0EEE8", margin: "14px 0" }} />
                        <div style={{ marginBottom: 14 }}>
                          <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.gray, letterSpacing: "0.1em", marginBottom: 8 }}>📝 NOTES</div>
                          <div style={{ fontSize: 12, color: COLORS.dark, background: COLORS.lightGray, borderRadius: 8, padding: "10px 12px", lineHeight: 1.65, whiteSpace: "pre-wrap" }}>
                            {selectedLead.notes}
                          </div>
                        </div>
                      </>
                    )}

                    {/* Photos */}
                    {selectedLead.photo_urls?.length > 0 && (
                      <>
                        <div style={{ height: 1, background: "#F0EEE8", margin: "14px 0" }} />
                        <div style={{ marginBottom: 14 }}>
                          <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.gray, letterSpacing: "0.1em", marginBottom: 8 }}>
                            📷 PHOTOS ({selectedLead.photo_urls.length})
                          </div>
                          <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                            {selectedLead.photo_urls.map((url, i) => (
                              <div key={i} style={{ fontSize: 11, background: COLORS.lightGray, borderRadius: 6, padding: "4px 9px", color: COLORS.gray }}>
                                📎 {url.includes("::") ? url.split("::")[0] : url}
                              </div>
                            ))}
                          </div>
                        </div>
                      </>
                    )}

                    <div style={{ height: 1, background: "#F0EEE8", margin: "14px 0" }} />

                    {/* Add admin note */}
                    <div style={{ marginBottom: 14 }}>
                      <div style={{ fontSize: 10, fontWeight: 700, color: COLORS.gray, letterSpacing: "0.1em", marginBottom: 8 }}>✏️ ADD NOTE</div>
                      <textarea
                        value={adminNote}
                        onChange={(e) => setAdminNote(e.target.value)}
                        rows={2}
                        placeholder="Add a note about this lead..."
                        style={{ width: "100%", padding: "9px 12px", border: "1.5px solid #DDD", borderRadius: 8, fontSize: 12, fontFamily: "inherit", outline: "none", resize: "vertical", boxSizing: "border-box" }}
                      />
                      <button onClick={saveAdminNote} disabled={!adminNote.trim() || savingNote}
                        style={{ marginTop: 6, background: savingNote || !adminNote.trim() ? "#CCC" : COLORS.dark, color: COLORS.white, border: "none", borderRadius: 8, padding: "8px 16px", cursor: !adminNote.trim() || savingNote ? "not-allowed" : "pointer", fontSize: 12, fontWeight: 600, fontFamily: "inherit" }}>
                        {savingNote ? "Saving..." : "Save Note"}
                      </button>
                    </div>

                    <div style={{ height: 1, background: "#F0EEE8", margin: "14px 0" }} />

                    {/* Quick actions */}
                    <div style={{ display: "grid", gap: 7 }}>
                      {selectedLead.phone && (
                        <a href={`tel:${selectedLead.phone}`} style={{ display: "block", background: COLORS.olive, color: COLORS.white, textDecoration: "none", borderRadius: 8, padding: "10px", textAlign: "center", fontSize: 13, fontWeight: 600 }}>
                          📞 Call {selectedLead.full_name?.split(" ")[0]}
                        </a>
                      )}
                      {selectedLead.email && (
                        <a
                          href={`mailto:${selectedLead.email}?subject=Your Ivory Shine Cleaning Appointment&body=Hi ${encodeURIComponent(selectedLead.full_name?.split(" ")[0] || "there")},%0D%0A%0D%0AThank you for contacting Ivory Shine Cleaning!%0D%0A%0D%0AWe have received your request for ${encodeURIComponent(selectedLead.cleaning_type || "cleaning services")} and we will be in touch shortly to confirm your appointment and final quote.%0D%0A%0D%0AIf you have any questions, please call us at 703-930-5056.%0D%0A%0D%0ABest regards,%0D%0AIvory Shine Cleaning%0D%0A703-930-5056%0D%0AInfo@ivoryshinecleaning.com`}
                          style={{ display: "block", background: COLORS.green || "#2D5A27", color: "#fff", textDecoration: "none", borderRadius: 8, padding: "10px", textAlign: "center", fontSize: 13, fontWeight: 600 }}>
                          ✉️ Email {selectedLead.full_name?.split(" ")[0]}
                        </a>
                      )}
                      <button onClick={() => updateLeadStatus(selectedLead.id, "Contacted")} disabled={selectedLead.status === "Contacted" || !!updatingId}
                        style={{ background: "transparent", color: STATUS_COLORS["Contacted"].text, border: `1.5px solid ${STATUS_COLORS["Contacted"].border}`, borderRadius: 8, padding: "10px", fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", opacity: selectedLead.status === "Contacted" ? 0.5 : 1 }}>
                        ✓ Mark as Contacted
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
