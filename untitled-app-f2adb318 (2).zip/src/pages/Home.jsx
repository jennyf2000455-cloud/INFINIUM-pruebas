import { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import IvyBot from '../components/IvyBot';

const WHATSAPP = "https://wa.me/17039305056";
const LOGO = "https://media.base44.com/images/public/69f4e671caaf925632125ab5/7a4dde46d_logooficial.png";
const HERO_BG = "https://media.base44.com/images/public/69f4e671caaf925632125ab5/8b0981530_logooficial.png";

// Before & After photos (original portfolio)
const WORK_PHOTOS = [
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/8fbe1037a_antesydesoues5.jpg", label_en:"Stove — Before & After", label_es:"Estufa — Antes y Después", tag_en:"Real Result", tag_es:"Resultado Real" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/64e717b51_antesydespues1.jpg", label_en:"Deep Clean — Before & After", label_es:"Limpieza Profunda — Antes y Después", tag_en:"Deep Clean", tag_es:"Limpieza Profunda" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/724af21c9_antesydespues2.jpg", label_en:"Switch Plate — Before & After", label_es:"Interruptor — Antes y Después", tag_en:"Detail Clean", tag_es:"Limpieza Detallada" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/e6f931726_antesydespues3.jpg", label_en:"Baseboards — Before & After", label_es:"Rodapiés — Antes y Después", tag_en:"Deep Clean", tag_es:"Limpieza Profunda" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/8173c688d_antesydespues4.jpg", label_en:"Sink — Before & After", label_es:"Lavabo — Antes y Después", tag_en:"Spotless Results", tag_es:"Resultados Impecables" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/b9c57f616_antesydespues6.jpg", label_en:"Door Frame — Before & After", label_es:"Marco de Puerta — Antes y Después", tag_en:"Detail Clean", tag_es:"Limpieza Detallada" },
];

// NEW: Real client homes gallery
const HOME_GALLERY = [
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/34fb800ab_ejemplo4.jpg",  label_en:"Gourmet Kitchen", label_es:"Cocina Gourmet" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/d4d2fe6ff_ejemplo5.jpg",  label_en:"Formal Dining Room", label_es:"Comedor Formal" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/a4ece072b_ejemplo8.jpg",  label_en:"Grand Foyer", label_es:"Entrada Principal" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/685d10c9b_ejemplo17.jpg", label_en:"Great Room", label_es:"Sala Principal" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/05770457a_ejemplo19.jpg", label_en:"Master Bedroom", label_es:"Habitación Principal" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/d5d7ba588_ejemplo23.jpg", label_en:"Elegant Bedroom", label_es:"Habitación Elegante" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/61f072bfc_ejemplo24.jpg", label_en:"Modern Bedroom", label_es:"Habitación Moderna" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/f67c3263a_ejemplo26.jpg", label_en:"Kids Room", label_es:"Habitación Infantil" },
  { url:"https://media.base44.com/images/public/69f4e671caaf925632125ab5/48e4bfc90_ejemplo28.jpg", label_en:"Living Room", label_es:"Sala de Estar" },
];

const COLORS = { gold:"#C8A44D", olive:"#7A8C5E", green:"#2D5A27", greenDark:"#1A3A15", greenDeep:"#0F2410", lime:"#8BC34A", white:"#FFFFFF", ivory:"#FAFAF7", dark:"#1A1A1A", gray:"#6B7280", lightGray:"#F5F5F0" };

const IVY_TYPE_MAP = { "Regular Home Cleaning":"Regular Home Cleaning","Deep Cleaning":"Deep Cleaning","Move-In / Move-Out Cleaning":"Move-In / Move-Out Cleaning","Office / Commercial Cleaning":"Office / Commercial Cleaning","Limpieza regular del hogar":"Regular Home Cleaning","Limpieza profunda":"Deep Cleaning","Limpieza de mudanza / Move-In / Move-Out":"Move-In / Move-Out Cleaning","Oficina / Comercial":"Office / Commercial Cleaning" };
const IVY_SIZE_MAP = { "Small space / apartment":"Small space / apartment","Medium home":"Medium home","Large home":"Large home","Not sure":"Not sure","Espacio pequeño / apartamento":"Small space / apartment","Casa mediana":"Medium home","Casa grande":"Large home","No estoy seguro":"Not sure" };
const IVY_SCHEDULE_MAP = { "As soon as possible":"As soon as possible","This week":"This week","Next week":"Next week","I want a call first":"I want a call first","Lo antes posible":"As soon as possible","Esta semana":"This week","La próxima semana":"Next week","Quiero una llamada primero":"I want a call first" };

const T = {
  en: {
    nav:["Services","About","Our Work","Contact"],
    trusted:"Trusted by 200+ clients in Virginia",
    hero_line1:"YOUR TIME", hero_line2:"MATTERS.", hero_line3:"WE CLEAN.",
    hero_cta1:"✦ Get Free Quote", hero_cta2:"Schedule Now",
    gallery_title:"Before & After Results",
    gallery_sub:"Real transformations from real homes — see the Ivory Shine difference.",
    homes_title:"Homes We Have Cleaned",
    homes_sub:"A glimpse into the spaces we take care of across Virginia.",
    ivy_title:"Meet IVY — Your Cleaning Assistant",
    ivy_sub:"Answer 3 quick questions and get your personalized estimate in under 30 seconds.",
    ivy_welcome:"Hi, I'm IVY, your Ivory Shine assistant. I'll ask you 3 quick questions to understand your cleaning needs and help you schedule your appointment.",
    q1:"What type of cleaning do you need?", q1_opts:["Regular Home Cleaning","Deep Cleaning","Move-In / Move-Out Cleaning","Office / Commercial Cleaning"],
    q2:"What size is the space?", q2_opts:["Small space / apartment","Medium home","Large home","Not sure"],
    q3:"When would you like to schedule?", q3_opts:["As soon as possible","This week","Next week","I want a call first"],
    ivy_result:"Great! Based on your answers, Ivory Shine can help you. To confirm availability and get your accurate quote, please schedule a quick appointment with our team.",
    ivy_disclaimer:"This is only an initial estimate. Final pricing depends on property condition, size, and availability.",
    btn_schedule:"Schedule Appointment", btn_whatsapp:"WhatsApp Us", btn_call_now:"Call Now",
    appt_title:"Schedule Your Appointment",
    appt_sub:"Fill in your details and we'll contact you to confirm availability and final quote.",
    form_name:"Full Name", form_phone:"Phone Number", form_email:"Email",
    form_date:"Preferred Date", form_time:"Preferred Time", form_address:"Address or ZIP Code",
    form_notes:"Cleaning Notes (optional)",
    form_submit:"Submit Appointment Request",
    form_confirm_title:"Request Received!",
    form_confirm:"Your appointment request has been received. Ivory Shine will contact you within 24 hours to confirm availability and final quote.",
    services_title:"Our Services", services_sub:"Professional cleaning tailored to your needs.",
    about_title:"About Ivory Shine", why_title:"Why Choose Ivory Shine?",
    why_points:["Over 10 years of experience","Reliable and professional service","Detail-oriented cleaning","Residential and commercial services","Peace of mind for every client","Premium service with personal care"],
    rotation_title:"The Detail-Clean Rotation System®",
    rotation_sub:"Our exclusive system designed to maintain a high level of cleanliness in your home on a consistent basis.",
    rotation_desc:"For clients scheduled on a weekly or biweekly basis, Ivory Shine applies the Detail-Clean Rotation System® to ensure the home stays consistently clean and well-maintained.",
    kitchen_title:"Kitchen & Eating Areas", kitchen_every:"On Every Visit, We Clean:", kitchen_rotation:"On Detail Rotation Day, We Add:",
    contact_title:"Contact Us", footer_tagline:"Your Time Matters. We Clean.",
    disclaimer_full:"All estimates are preliminary. Final pricing may vary depending on property condition, exact size, requested details, location, and availability.",
    wa_cta:"Chat on WhatsApp",
  },
  es: {
    nav:["Servicios","Nosotros","Nuestro Trabajo","Contacto"],
    trusted:"Con la confianza de 200+ clientes en Virginia",
    hero_line1:"TU TIEMPO", hero_line2:"IMPORTA.", hero_line3:"LIMPIAMOS.",
    hero_cta1:"✦ Cotización Gratis", hero_cta2:"Agendar Ahora",
    gallery_title:"Resultados Antes y Después",
    gallery_sub:"Transformaciones reales de hogares reales — conoce la diferencia Ivory Shine.",
    homes_title:"Hogares que Hemos Limpiado",
    homes_sub:"Un vistazo a los espacios que cuidamos en toda Virginia.",
    ivy_title:"Conoce a IVY — Tu Asistente de Limpieza",
    ivy_sub:"Responde 3 preguntas rápidas y obtén tu estimado en menos de 30 segundos.",
    ivy_welcome:"Hola, soy IVY, tu asistente de Ivory Shine. Te haré 3 preguntas rápidas para entender tu limpieza y ayudarte a agendar tu cita.",
    q1:"¿Qué tipo de limpieza necesitas?", q1_opts:["Limpieza regular del hogar","Limpieza profunda","Limpieza de mudanza / Move-In / Move-Out","Oficina / Comercial"],
    q2:"¿Qué tamaño tiene el lugar?", q2_opts:["Espacio pequeño / apartamento","Casa mediana","Casa grande","No estoy seguro"],
    q3:"¿Cuándo te gustaría agendar?", q3_opts:["Lo antes posible","Esta semana","La próxima semana","Quiero una llamada primero"],
    ivy_result:"¡Perfecto! Según tus respuestas, Ivory Shine puede ayudarte. Para confirmar disponibilidad y darte tu cotización exacta, agenda una cita rápida.",
    ivy_disclaimer:"Este es solo un estimado inicial. El precio final depende de la condición, tamaño y disponibilidad.",
    btn_schedule:"Agendar Cita", btn_whatsapp:"WhatsApp", btn_call_now:"Llamar Ahora",
    appt_title:"Agenda Tu Cita",
    appt_sub:"Llena tus datos y nos comunicaremos para confirmar disponibilidad y cotización final.",
    form_name:"Nombre Completo", form_phone:"Número de Teléfono", form_email:"Correo Electrónico",
    form_date:"Fecha Preferida", form_time:"Hora Preferida", form_address:"Dirección o Código Postal",
    form_notes:"Notas de Limpieza (opcional)",
    form_submit:"Enviar Solicitud de Cita",
    form_confirm_title:"¡Solicitud Recibida!",
    form_confirm:"Tu solicitud ha sido recibida. Ivory Shine se comunicará contigo en menos de 24 horas para confirmar disponibilidad y cotización final.",
    services_title:"Nuestros Servicios", services_sub:"Limpieza profesional adaptada a tus necesidades.",
    about_title:"Sobre Ivory Shine", why_title:"¿Por Qué Elegir Ivory Shine?",
    why_points:["Más de 10 años de experiencia","Servicio confiable y profesional","Limpieza orientada al detalle","Servicios residenciales y comerciales","Tranquilidad para cada cliente","Servicio premium con atención personal"],
    rotation_title:"El Sistema Detail-Clean Rotation®",
    rotation_sub:"Nuestro sistema exclusivo diseñado para mantener un alto nivel de limpieza constante.",
    rotation_desc:"Para clientes con servicio semanal o quincenal, Ivory Shine aplica este sistema para asegurar que el hogar se mantenga limpio y bien mantenido.",
    kitchen_title:"Cocina y Áreas de Comida", kitchen_every:"En Cada Visita, Limpiamos:", kitchen_rotation:"En el Día de Rotación Detallada, Añadimos:",
    contact_title:"Contáctanos", footer_tagline:"Tu tiempo importa. Nosotros limpiamos.",
    disclaimer_full:"Todos los estimados son preliminares. El precio final puede variar según la condición, tamaño, detalles, ubicación y disponibilidad.",
    wa_cta:"Chatear por WhatsApp",
  },
};

const services = [
  { icon:"🏠", key:"Residential Cleaning", desc_en:"Regular cleaning for your home, tailored to your schedule and preferences.", desc_es:"Limpieza regular para tu hogar, adaptada a tu horario y preferencias." },
  { icon:"✨", key:"First-Time Deep Cleaning", desc_en:"A thorough top-to-bottom clean for first-time clients or homes needing extra attention.", desc_es:"Limpieza profunda de arriba a abajo para nuevos clientes." },
  { icon:"📦", key:"Move-In / Move-Out Cleaning", desc_en:"Complete cleaning for moving transitions, ensuring a fresh start.", desc_es:"Servicio completo de limpieza para mudanzas." },
  { icon:"🏢", key:"Apartment Cleaning", desc_en:"Specialized cleaning for apartments, keeping your space fresh and organized.", desc_es:"Limpieza especializada para apartamentos." },
  { icon:"💼", key:"Commercial Cleaning", desc_en:"Professional cleaning for offices and small businesses in Virginia.", desc_es:"Limpieza profesional para oficinas y pequeños negocios." },
  { icon:"🍳", key:"Detailed Kitchen Cleaning", desc_en:"Deep kitchen cleaning including appliances, countertops, and cabinets.", desc_es:"Limpieza profunda de cocina incluyendo electrodomésticos y gabinetes." },
  { icon:"🚿", key:"Bathroom Deep Cleaning", desc_en:"Sanitizing and deep cleaning of all bathroom surfaces.", desc_es:"Saneamiento y limpieza profunda del baño." },
  { icon:"⭐", key:"Custom Cleaning Services", desc_en:"Tailored cleaning solutions based on your specific needs.", desc_es:"Soluciones de limpieza personalizadas." },
];

const kitchenEvery = ["Countertops and high-touch surfaces cleaned and sanitized","Outside of range hood, top and front of range cleaned","Sinks cleaned and chrome shined","Fronts of all appliances cleaned","Floors vacuumed and damp-mopped","Microwave cleaned inside and out","General dusting","Fronts of cabinets"];
const kitchenRotation = ["Inside of range hood cleaned","Doors and door frames hand-wiped","Appliances cleaned and shined","Fronts of cabinets hand-wiped","Baseboards and window sills hand-wiped","Floors given extra attention","All kitchen furniture hand-wiped"];

export default function Home() {
  const [lang, setLang] = useState("en");
  const t = T[lang];
  const appointmentRef = useRef(null);
  const ivyRef = useRef(null);
  const [ivyStep, setIvyStep] = useState(0);
  const [ivyAnswers, setIvyAnswers] = useState({ q1:"", q2:"", q3:"" });
  const [form, setForm] = useState({ full_name:"", phone:"", email:"", preferred_date:"", preferred_time:"", address_zip:"", notes:"" });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [lightboxImg, setLightboxImg] = useState(null);

  const handleIvyAnswer = (q, answer) => { setIvyAnswers(p => ({ ...p, [q]: answer })); setIvyStep(p => p + 1); };

  const handleIvySave = async (data) => {
    try {
      await base44.functions.invoke("createLead", {
        full_name: data.full_name,
        phone: data.phone,
        email: data.email || "",
        cleaning_type: data.cleaning_type,
        space_size: data.space_size,
        desired_schedule: data.desired_schedule,
        lead_source: "IVY Bot",
        status: "New",
      });
    } catch(e) {
      console.error("IVY save error:", e);
    }
  };
  const scrollTo = (ref) => ref?.current?.scrollIntoView({ behavior:"smooth", block:"start" });
  const scrollToId = (id) => document.getElementById(id)?.scrollIntoView({ behavior:"smooth" });
  const openIvy = () => { setIvyStep(0); setIvyAnswers({ q1:"",q2:"",q3:"" }); setTimeout(() => scrollTo(ivyRef), 100); };
  const goToAppt = () => setTimeout(() => scrollTo(appointmentRef), 100);

  // Submit via REST API — no SDK dependency, avoids 403 private app error
  const handleSubmit = async (e) => {
    e.preventDefault();
    const nameVal = (form.full_name || "").trim();
    const phoneVal = (form.phone || "").trim();
    if (!nameVal || !phoneVal) {
      setSubmitError(lang==="en"?"Please fill in your name and phone.":"Por favor ingresa nombre y teléfono.");
      return;
    }
    setSubmitError(""); setSubmitting(true);
    try {
      const payload = {
        full_name: nameVal,
        phone: phoneVal,
        cleaning_type: IVY_TYPE_MAP[ivyAnswers.q1] || "Regular Home Cleaning",
        space_size: IVY_SIZE_MAP[ivyAnswers.q2] || "Not sure",
        desired_schedule: IVY_SCHEDULE_MAP[ivyAnswers.q3] || "As soon as possible",
        lead_source: ivyAnswers.q1 ? "IVY Bot" : "Website Form",
        status: "New",
      };
      if ((form.email||"").trim()) payload.email = form.email.trim();
      if (form.preferred_date) payload.preferred_date = form.preferred_date;
      if (form.preferred_time) payload.preferred_time = form.preferred_time;
      if ((form.address_zip||"").trim()) payload.address_zip = form.address_zip.trim();
      if ((form.notes||"").trim()) payload.notes = form.notes.trim();

      await base44.functions.invoke("createLead", payload);

      setSubmitted(true);
      setForm({ full_name:"", phone:"", email:"", preferred_date:"", preferred_time:"", address_zip:"", notes:"" });
    } catch(err) {
      console.error("Submit error:", err);
      setSubmitError(lang==="en"
        ? "Something went wrong. Please call 703-930-5056 or WhatsApp us."
        : "Algo salió mal. Por favor llama al 703-930-5056 o escríbenos por WhatsApp.");
    }
    setSubmitting(false);
  };

  const inp = { width:"100%", padding:"12px 14px", border:"1.5px solid #DDD", borderRadius:10, fontSize:14, fontFamily:"inherit", outline:"none", boxSizing:"border-box", background:"#fff", color:COLORS.dark };

  return (
    <div style={{ fontFamily:"'Georgia',serif", background:COLORS.ivory, color:COLORS.dark, minHeight:"100vh" }}>
      <style>{`
        *{box-sizing:border-box;}
        @media(max-width:768px){.dnav{display:none!important;}.hero-line{font-size:clamp(36px,11vw,68px)!important;}.two-col{grid-template-columns:1fr!important;}.svc-grid{grid-template-columns:1fr 1fr!important;}.kitchen-grid{grid-template-columns:1fr!important;}.cg{grid-template-columns:1fr 1fr!important;}.gallery-grid{grid-template-columns:1fr 1fr!important;}.homes-grid{grid-template-columns:1fr 1fr!important;}}
        @media(max-width:480px){.svc-grid{grid-template-columns:1fr!important;}.cg{grid-template-columns:1fr!important;}.gallery-grid{grid-template-columns:1fr!important;}.homes-grid{grid-template-columns:1fr!important;}}
        input:focus,textarea:focus{border-color:#2D5A27!important;box-shadow:0 0 0 3px rgba(45,90,39,0.1)!important;}
        .nbtn:hover{color:#8BC34A!important;}
        .sc:hover{transform:translateY(-5px)!important;box-shadow:0 14px 36px rgba(45,90,39,0.14)!important;}
        .ivy-o:hover{border-color:#C8A44D!important;background:rgba(200,164,77,0.04)!important;}
        .gcard:hover{transform:scale(1.03)!important;box-shadow:0 12px 32px rgba(0,0,0,0.18)!important;}
        .gcard{transition:all 0.2s;cursor:pointer;}
        .wa-float:hover{transform:scale(1.1)!important;}
        .wa-float{transition:transform 0.2s!important;}
      `}</style>

      {/* ══ NAVBAR ══ */}
      <nav style={{ background:COLORS.greenDeep, borderBottom:"1px solid rgba(255,255,255,0.07)", position:"sticky", top:0, zIndex:100, boxShadow:"0 2px 20px rgba(0,0,0,0.4)" }}>
        <div style={{ maxWidth:1200, margin:"0 auto", padding:"0 24px", display:"flex", alignItems:"center", justifyContent:"space-between", height:66 }}>
          <div style={{ display:"flex", alignItems:"center", gap:10, cursor:"pointer" }} onClick={() => window.scrollTo({top:0,behavior:"smooth"})}>
            <div style={{ width:44, height:44, borderRadius:"50%", background:"#fff", display:"flex", alignItems:"center", justifyContent:"center", overflow:"hidden", flexShrink:0, boxShadow:"0 2px 8px rgba(0,0,0,0.3)" }}>
              <img src={LOGO} alt="Ivory Shine" style={{ width:40, height:40, objectFit:"contain" }} />
            </div>
            <div>
              <div style={{ color:"#fff", fontSize:14, fontWeight:700, lineHeight:1.2 }}>Ivory Shine Cleaning</div>
              <div style={{ color:COLORS.lime, fontSize:10, letterSpacing:"0.08em" }}>Your Time Matters. We Clean.</div>
            </div>
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:14 }}>
            <div className="dnav" style={{ display:"flex", gap:26 }}>
              {[["services-section",t.nav[0]],["about-section",t.nav[1]],["homes-section",t.nav[2]],["contact-section",t.nav[3]]].map(([id,label]) => (
                <button key={id} onClick={() => scrollToId(id)} className="nbtn" style={{ background:"none", border:"none", cursor:"pointer", color:"rgba(255,255,255,0.82)", fontSize:13, fontFamily:"inherit", letterSpacing:"0.06em", fontWeight:500, transition:"color 0.2s" }}>{label}</button>
              ))}
            </div>
            <div style={{ display:"flex", background:"rgba(255,255,255,0.1)", borderRadius:20, padding:3, gap:2 }}>
              {["en","es"].map(l => (
                <button key={l} onClick={() => setLang(l)} style={{ padding:"4px 12px", borderRadius:16, border:"none", cursor:"pointer", fontSize:11, fontWeight:700, letterSpacing:"0.08em", background:lang===l?COLORS.gold:"transparent", color:lang===l?"#fff":"rgba(255,255,255,0.55)", transition:"all 0.2s" }}>{l.toUpperCase()}</button>
              ))}
            </div>
            <a href={WHATSAPP} target="_blank" rel="noopener noreferrer" style={{ background:"#25D366", color:"#fff", border:"none", borderRadius:22, padding:"10px 18px", cursor:"pointer", fontSize:12, fontWeight:800, letterSpacing:"0.04em", textDecoration:"none", display:"flex", alignItems:"center", gap:6, boxShadow:"0 4px 14px rgba(37,211,102,0.4)" }}>
              <span style={{ fontSize:16 }}>💬</span> WhatsApp
            </a>
          </div>
        </div>
      </nav>

      {/* ══ HERO ══ */}
      <section style={{ position:"relative", minHeight:"90vh", display:"flex", alignItems:"center", overflow:"hidden" }}>
        <div style={{ position:"absolute", inset:0, zIndex:0 }}>
          <img src={HERO_BG} alt="" style={{ width:"100%", height:"100%", objectFit:"cover", objectPosition:"center top", opacity:0.55, filter:"saturate(0.7) brightness(0.9)" }} />
          <div style={{ position:"absolute", inset:0, background:"linear-gradient(105deg, rgba(10,28,8,0.82) 0%, rgba(15,40,12,0.65) 40%, rgba(10,30,10,0.30) 70%, rgba(5,20,5,0.10) 100%)" }} />
        </div>
        <div style={{ maxWidth:1200, margin:"0 auto", padding:"80px 32px", width:"100%", position:"relative", zIndex:2 }}>
          <div style={{ display:"inline-flex", alignItems:"center", gap:8, background:"rgba(139,195,74,0.15)", border:"1px solid rgba(139,195,74,0.45)", borderRadius:22, padding:"7px 16px", marginBottom:26 }}>
            <span style={{ fontSize:13 }}>⭐</span>
            <span style={{ color:COLORS.lime, fontSize:12, fontWeight:600, letterSpacing:"0.04em" }}>{t.trusted}</span>
          </div>
          <div style={{ marginBottom:10 }}>
            {[t.hero_line1, t.hero_line2, t.hero_line3].map((line, i) => (
              <div key={i} className="hero-line" style={{ fontSize:"clamp(42px,7vw,80px)", fontWeight:900, lineHeight:1.0, letterSpacing:"-0.01em", fontFamily:"Arial Black,Impact,sans-serif", color:i===1?COLORS.lime:"#fff", textShadow:"0 2px 12px rgba(0,0,0,0.5)" }}>{line}</div>
            ))}
          </div>
          <p style={{ fontSize:"clamp(14px,1.6vw,17px)", color:"rgba(255,255,255,0.88)", lineHeight:1.8, margin:"20px 0 34px", maxWidth:480, textShadow:"0 1px 6px rgba(0,0,0,0.4)" }}>
            {lang==="en" ? <>Professional cleaning services designed to create <span style={{ color:COLORS.lime, fontWeight:600 }}>clean, peaceful, and comfortable</span> spaces.</> : <>Servicios de limpieza diseñados para crear espacios <span style={{ color:COLORS.lime, fontWeight:600 }}>limpios, tranquilos y cómodos</span>.</>}
          </p>
          <div style={{ display:"flex", gap:14, flexWrap:"wrap" }}>
            <button onClick={openIvy} style={{ background:COLORS.lime, color:COLORS.dark, border:"none", borderRadius:28, padding:"15px 32px", cursor:"pointer", fontSize:14, fontWeight:800, letterSpacing:"0.04em", boxShadow:"0 6px 24px rgba(139,195,74,0.5)" }}>{t.hero_cta1}</button>
            <a href={WHATSAPP} target="_blank" rel="noopener noreferrer" style={{ background:"#25D366", color:"#fff", borderRadius:28, padding:"15px 28px", cursor:"pointer", fontSize:14, fontWeight:700, letterSpacing:"0.04em", textDecoration:"none", display:"flex", alignItems:"center", gap:8, boxShadow:"0 6px 24px rgba(37,211,102,0.4)" }}>
              <span>💬</span> {t.btn_whatsapp}
            </a>
            <button onClick={goToAppt} style={{ background:"rgba(255,255,255,0.12)", color:"#fff", border:"2px solid rgba(255,255,255,0.4)", borderRadius:28, padding:"15px 28px", cursor:"pointer", fontSize:14, fontWeight:600 }}>{t.hero_cta2}</button>
          </div>
          <div style={{ display:"flex", gap:32, marginTop:36, flexWrap:"wrap" }}>
            {[["10+",lang==="en"?"Years Exp.":"Años de Exp."],["200+",lang==="en"?"Happy Clients":"Clientes Felices"],["5.0★",lang==="en"?"Rating":"Calificación"]].map(([val,label]) => (
              <div key={label}>
                <div style={{ fontSize:24, fontWeight:800, color:"#fff", textShadow:"0 2px 8px rgba(0,0,0,0.4)" }}>{val}</div>
                <div style={{ fontSize:11, color:"rgba(255,255,255,0.65)", letterSpacing:"0.06em" }}>{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ BEFORE & AFTER GALLERY ══ */}
      <section style={{ background:COLORS.lightGray, padding:"72px 24px" }}>
        <div style={{ maxWidth:1200, margin:"0 auto" }}>
          <div style={{ textAlign:"center", marginBottom:48 }}>
            <div style={{ display:"inline-block", background:COLORS.greenDeep, color:COLORS.lime, fontSize:11, fontWeight:700, letterSpacing:"0.15em", padding:"6px 18px", borderRadius:20, marginBottom:16 }}>PORTFOLIO</div>
            <h2 style={{ fontSize:"clamp(26px,4vw,40px)", fontWeight:800, color:COLORS.dark, margin:"0 0 14px" }}>{t.gallery_title}</h2>
            <p style={{ color:COLORS.gray, fontSize:15, maxWidth:500, margin:"0 auto" }}>{t.gallery_sub}</p>
          </div>
          <div className="gallery-grid" style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:20 }}>
            {WORK_PHOTOS.map((p,i) => (
              <div key={i} className="gcard" onClick={() => setLightboxImg(p.url)} style={{ borderRadius:14, overflow:"hidden", position:"relative", aspectRatio:"4/3", background:"#eee" }}>
                <img src={p.url} alt={p.label_en} style={{ width:"100%", height:"100%", objectFit:"cover" }} />
                <div style={{ position:"absolute", inset:0, background:"linear-gradient(to top, rgba(0,0,0,0.65) 0%, transparent 55%)" }} />
                <div style={{ position:"absolute", bottom:0, left:0, right:0, padding:"14px 16px" }}>
                  <div style={{ background:COLORS.lime, color:COLORS.dark, fontSize:9, fontWeight:800, letterSpacing:"0.12em", padding:"3px 10px", borderRadius:12, display:"inline-block", marginBottom:6 }}>{lang==="en"?p.tag_en:p.tag_es}</div>
                  <div style={{ color:"#fff", fontSize:13, fontWeight:600 }}>{lang==="en"?p.label_en:p.label_es}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ HOMES WE CLEAN — NEW SECTION ══ */}
      <section id="homes-section" style={{ background:"#fff", padding:"72px 24px" }}>
        <div style={{ maxWidth:1200, margin:"0 auto" }}>
          <div style={{ textAlign:"center", marginBottom:48 }}>
            <div style={{ display:"inline-block", background:COLORS.greenDeep, color:COLORS.lime, fontSize:11, fontWeight:700, letterSpacing:"0.15em", padding:"6px 18px", borderRadius:20, marginBottom:16 }}>OUR CLIENTS</div>
            <h2 style={{ fontSize:"clamp(26px,4vw,40px)", fontWeight:800, color:COLORS.dark, margin:"0 0 14px" }}>{t.homes_title}</h2>
            <p style={{ color:COLORS.gray, fontSize:15, maxWidth:520, margin:"0 auto" }}>{t.homes_sub}</p>
          </div>
          <div className="homes-grid" style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:20 }}>
            {HOME_GALLERY.map((p,i) => (
              <div key={i} className="gcard" onClick={() => setLightboxImg(p.url)} style={{ borderRadius:16, overflow:"hidden", position:"relative", aspectRatio:"4/5", background:"#eee", boxShadow:"0 4px 16px rgba(0,0,0,0.10)" }}>
                <img src={p.url} alt={p.label_en} style={{ width:"100%", height:"100%", objectFit:"cover" }} loading="lazy" />
                <div style={{ position:"absolute", inset:0, background:"linear-gradient(to top, rgba(15,36,16,0.75) 0%, transparent 50%)" }} />
                <div style={{ position:"absolute", bottom:0, left:0, right:0, padding:"16px" }}>
                  <div style={{ color:"#fff", fontSize:13, fontWeight:700, textShadow:"0 1px 4px rgba(0,0,0,0.5)" }}>{lang==="en"?p.label_en:p.label_es}</div>
                </div>
              </div>
            ))}
          </div>
          {/* WhatsApp CTA after gallery */}
          <div style={{ textAlign:"center", marginTop:48 }}>
            <a href={WHATSAPP} target="_blank" rel="noopener noreferrer" style={{ display:"inline-flex", alignItems:"center", gap:10, background:"#25D366", color:"#fff", textDecoration:"none", borderRadius:32, padding:"16px 36px", fontSize:16, fontWeight:800, boxShadow:"0 8px 28px rgba(37,211,102,0.4)", letterSpacing:"0.02em" }}>
              <span style={{ fontSize:22 }}>💬</span> {t.wa_cta}
            </a>
          </div>
        </div>
      </section>

      {/* ══ SERVICES ══ */}
      <section id="services-section" style={{ background:COLORS.lightGray, padding:"72px 24px" }}>
        <div style={{ maxWidth:1200, margin:"0 auto" }}>
          <div style={{ textAlign:"center", marginBottom:48 }}>
            <div style={{ display:"inline-block", background:COLORS.greenDeep, color:COLORS.lime, fontSize:11, fontWeight:700, letterSpacing:"0.15em", padding:"6px 18px", borderRadius:20, marginBottom:16 }}>SERVICES</div>
            <h2 style={{ fontSize:"clamp(26px,4vw,40px)", fontWeight:800, color:COLORS.dark, margin:"0 0 14px" }}>{t.services_title}</h2>
            <p style={{ color:COLORS.gray, fontSize:15 }}>{t.services_sub}</p>
          </div>
          <div className="svc-grid" style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:20 }}>
            {services.map((s,i) => (
              <div key={i} className="sc" style={{ background:"#fff", borderRadius:16, padding:"26px 20px", border:`1px solid #E8E4D8`, transition:"all 0.25s", cursor:"default" }}>
                <div style={{ fontSize:32, marginBottom:14 }}>{s.icon}</div>
                <h3 style={{ fontSize:15, fontWeight:700, color:COLORS.dark, margin:"0 0 10px" }}>{s.key}</h3>
                <p style={{ color:COLORS.gray, fontSize:13, lineHeight:1.7, margin:0 }}>{lang==="en"?s.desc_en:s.desc_es}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ IVY BOT ══ */}
      <section id="ivy-section" ref={ivyRef} style={{ background:"#fff", padding:"72px 24px" }}>
        <div style={{ maxWidth:700, margin:"0 auto" }}>
          <div style={{ textAlign:"center", marginBottom:40 }}>
            <div style={{ display:"inline-block", background:COLORS.greenDeep, color:COLORS.lime, fontSize:11, fontWeight:700, letterSpacing:"0.15em", padding:"6px 18px", borderRadius:20, marginBottom:16 }}>IVY ASSISTANT</div>
            <h2 style={{ fontSize:"clamp(22px,3.5vw,36px)", fontWeight:800, color:COLORS.dark, margin:"0 0 12px" }}>{t.ivy_title}</h2>
            <p style={{ color:COLORS.gray, fontSize:15 }}>{t.ivy_sub}</p>
          </div>
          <div style={{ display:"flex", justifyContent:"center" }}>
            <IvyBot
              lang={lang}
              onSchedule={() => document.getElementById('appointment')?.scrollIntoView({ behavior: 'smooth' })}
              onSave={handleIvySave}
            />
          </div>
        </div>
      </section>

      {/* ══ APPOINTMENT FORM ══ */}
      <section ref={appointmentRef} style={{ background:COLORS.lightGray, padding:"72px 24px" }}>
        <div style={{ maxWidth:680, margin:"0 auto" }}>
          <div style={{ textAlign:"center", marginBottom:40 }}>
            <div style={{ display:"inline-block", background:COLORS.greenDeep, color:COLORS.lime, fontSize:11, fontWeight:700, letterSpacing:"0.15em", padding:"6px 18px", borderRadius:20, marginBottom:16 }}>BOOK NOW</div>
            <h2 style={{ fontSize:"clamp(22px,3.5vw,36px)", fontWeight:800, color:COLORS.dark, margin:"0 0 12px" }}>{t.appt_title}</h2>
            <p style={{ color:COLORS.gray, fontSize:15 }}>{t.appt_sub}</p>
          </div>
          {submitted ? (
            <div style={{ background:"#fff", borderRadius:20, padding:"48px 36px", textAlign:"center", boxShadow:"0 4px 24px rgba(0,0,0,0.08)", border:`2px solid ${COLORS.lime}` }}>
              <div style={{ fontSize:56, marginBottom:16 }}>✅</div>
              <h3 style={{ fontSize:24, fontWeight:800, color:COLORS.green, marginBottom:12 }}>{t.form_confirm_title}</h3>
              <p style={{ color:COLORS.gray, fontSize:15, lineHeight:1.7 }}>{t.form_confirm}</p>
              <a href={WHATSAPP} target="_blank" rel="noopener noreferrer" style={{ display:"inline-flex", alignItems:"center", gap:8, background:"#25D366", color:"#fff", textDecoration:"none", borderRadius:14, padding:"13px 28px", fontSize:15, fontWeight:700, marginTop:24 }}>
                <span>💬</span> {t.wa_cta}
              </a>
            </div>
          ) : (
            <form onSubmit={handleSubmit} style={{ background:"#fff", borderRadius:20, padding:"36px 32px", boxShadow:"0 4px 24px rgba(0,0,0,0.08)" }}>
              <div className="two-col" style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:16 }}>
                <div>
                  <label style={{ fontSize:12, fontWeight:700, color:COLORS.dark, display:"block", marginBottom:6 }}>{t.form_name} *</label>
                  <input style={inp} value={form.full_name} onChange={e=>setForm(p=>({...p,full_name:e.target.value}))} placeholder="Sara Medina" required />
                </div>
                <div>
                  <label style={{ fontSize:12, fontWeight:700, color:COLORS.dark, display:"block", marginBottom:6 }}>{t.form_phone} *</label>
                  <input style={inp} value={form.phone} onChange={e=>setForm(p=>({...p,phone:e.target.value}))} placeholder="703-000-0000" required />
                </div>
              </div>
              <div style={{ marginBottom:16 }}>
                <label style={{ fontSize:12, fontWeight:700, color:COLORS.dark, display:"block", marginBottom:6 }}>{t.form_email}</label>
                <input style={inp} type="email" value={form.email} onChange={e=>setForm(p=>({...p,email:e.target.value}))} placeholder="email@example.com" />
              </div>
              <div className="two-col" style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:16 }}>
                <div>
                  <label style={{ fontSize:12, fontWeight:700, color:COLORS.dark, display:"block", marginBottom:6 }}>{t.form_date}</label>
                  <input style={inp} type="date" value={form.preferred_date} onChange={e=>setForm(p=>({...p,preferred_date:e.target.value}))} />
                </div>
                <div>
                  <label style={{ fontSize:12, fontWeight:700, color:COLORS.dark, display:"block", marginBottom:6 }}>{t.form_time}</label>
                  <input style={inp} type="time" value={form.preferred_time} onChange={e=>setForm(p=>({...p,preferred_time:e.target.value}))} />
                </div>
              </div>
              <div style={{ marginBottom:16 }}>
                <label style={{ fontSize:12, fontWeight:700, color:COLORS.dark, display:"block", marginBottom:6 }}>{t.form_address}</label>
                <input style={inp} value={form.address_zip} onChange={e=>setForm(p=>({...p,address_zip:e.target.value}))} placeholder="Arlington VA 22201" />
              </div>
              <div style={{ marginBottom:24 }}>
                <label style={{ fontSize:12, fontWeight:700, color:COLORS.dark, display:"block", marginBottom:6 }}>{t.form_notes}</label>
                <textarea style={{ ...inp, height:90, resize:"vertical" }} value={form.notes} onChange={e=>setForm(p=>({...p,notes:e.target.value}))} placeholder={lang==="en"?"Any specific requests or areas of focus...":"Solicitudes específicas o áreas de enfoque..."} />
              </div>
              {submitError && <div style={{ background:"#FEF2F2", border:"1px solid #FECACA", borderRadius:10, padding:"12px 16px", color:"#DC2626", fontSize:13, marginBottom:16 }}>{submitError}</div>}
              <button type="submit" disabled={submitting} style={{ width:"100%", background:submitting?"#94A3B8":COLORS.greenDeep, color:"#fff", border:"none", borderRadius:14, padding:"16px", fontSize:16, fontWeight:800, cursor:submitting?"not-allowed":"pointer", fontFamily:"inherit", letterSpacing:"0.02em", transition:"background 0.2s" }}>
                {submitting ? (lang==="en"?"Sending...":"Enviando...") : t.form_submit}
              </button>
              <div style={{ textAlign:"center", marginTop:16 }}>
                <a href={WHATSAPP} target="_blank" rel="noopener noreferrer" style={{ display:"inline-flex", alignItems:"center", gap:8, color:"#25D366", textDecoration:"none", fontSize:14, fontWeight:700 }}>
                  <span>💬</span> {lang==="en"?"Prefer WhatsApp?":"¿Prefieres WhatsApp?"} {t.btn_whatsapp}
                </a>
              </div>
            </form>
          )}
        </div>
      </section>

      {/* ══ ABOUT ══ */}
      <section id="about-section" style={{ background:"#fff", padding:"72px 24px" }}>
        <div style={{ maxWidth:1100, margin:"0 auto" }}>
          <div className="two-col" style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:56, alignItems:"center" }}>
            <div>
              <div style={{ display:"inline-block", background:COLORS.greenDeep, color:COLORS.lime, fontSize:11, fontWeight:700, letterSpacing:"0.15em", padding:"6px 18px", borderRadius:20, marginBottom:20 }}>ABOUT US</div>
              <h2 style={{ fontSize:"clamp(24px,3.5vw,40px)", fontWeight:800, color:COLORS.dark, margin:"0 0 20px" }}>{t.about_title}</h2>
              <p style={{ color:COLORS.gray, fontSize:15, lineHeight:1.9, marginBottom:20 }}>
                {lang==="en" ? "Ivory Shine Cleaning LLC is a premium residential and commercial cleaning service based in Virginia. Founded by a former teacher with over 10 years of experience, our company brings the same dedication and care to every home we clean." : "Ivory Shine Cleaning LLC es un servicio premium de limpieza residencial y comercial con sede en Virginia. Fundado por una ex maestra con más de 10 años de experiencia, nuestra empresa brinda la misma dedicación y cuidado a cada hogar que limpiamos."}
              </p>
              <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
                {t.why_points.map((p,i) => (
                  <div key={i} style={{ display:"flex", alignItems:"center", gap:12 }}>
                    <div style={{ width:22, height:22, borderRadius:"50%", background:COLORS.lime, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, fontSize:11 }}>✓</div>
                    <span style={{ fontSize:14, color:COLORS.dark }}>{p}</span>
                  </div>
                ))}
              </div>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
              {HOME_GALLERY.slice(0,4).map((p,i) => (
                <div key={i} style={{ borderRadius:14, overflow:"hidden", aspectRatio:"1", boxShadow:"0 4px 16px rgba(0,0,0,0.1)" }}>
                  <img src={p.url} alt={p.label_en} style={{ width:"100%", height:"100%", objectFit:"cover" }} loading="lazy" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ══ CONTACT ══ */}
      <section id="contact-section" style={{ background:COLORS.greenDeep, padding:"72px 24px" }}>
        <div style={{ maxWidth:700, margin:"0 auto", textAlign:"center" }}>
          <h2 style={{ fontSize:"clamp(26px,4vw,42px)", fontWeight:800, color:"#fff", margin:"0 0 16px" }}>{t.contact_title}</h2>
          <p style={{ color:"rgba(255,255,255,0.7)", fontSize:16, marginBottom:40 }}>
            {lang==="en" ? "Ready to schedule? Contact us today." : "¿Listo para agendar? Contáctanos hoy."}
          </p>
          <div style={{ display:"flex", justifyContent:"center", gap:20, flexWrap:"wrap" }}>
            <a href={WHATSAPP} target="_blank" rel="noopener noreferrer" style={{ display:"flex", alignItems:"center", gap:10, background:"#25D366", color:"#fff", textDecoration:"none", borderRadius:16, padding:"16px 32px", fontSize:16, fontWeight:800, boxShadow:"0 8px 28px rgba(37,211,102,0.4)" }}>
              <span style={{ fontSize:22 }}>💬</span> WhatsApp
            </a>
            <a href="tel:7039305056" style={{ display:"flex", alignItems:"center", gap:10, background:COLORS.gold, color:"#fff", textDecoration:"none", borderRadius:16, padding:"16px 32px", fontSize:16, fontWeight:800, boxShadow:"0 8px 28px rgba(200,164,77,0.4)" }}>
              <span style={{ fontSize:22 }}>📞</span> 703-930-5056
            </a>
            <a href="mailto:Info@ivoryshinecleaning.com" style={{ display:"flex", alignItems:"center", gap:10, background:"rgba(255,255,255,0.12)", color:"#fff", textDecoration:"none", borderRadius:16, padding:"16px 32px", fontSize:16, fontWeight:700, border:"1.5px solid rgba(255,255,255,0.3)" }}>
              <span style={{ fontSize:22 }}>✉️</span> Email
            </a>
          </div>
        </div>
      </section>

      {/* ══ FOOTER ══ */}
      <footer style={{ background:"#060E06", padding:"28px 24px", textAlign:"center" }}>
        <img src={LOGO} alt="Ivory Shine" style={{ height:40, marginBottom:12, objectFit:"contain" }} />
        <p style={{ color:"rgba(255,255,255,0.35)", fontSize:12, margin:0 }}>© 2025 Ivory Shine Cleaning LLC · Virginia, USA · {t.footer_tagline}</p>
        <p style={{ color:"rgba(255,255,255,0.2)", fontSize:11, margin:"8px 0 0", fontStyle:"italic" }}>{t.disclaimer_full}</p>
      </footer>

      {/* ══ LIGHTBOX ══ */}
      {lightboxImg && (
        <div onClick={() => setLightboxImg(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.92)", zIndex:999, display:"flex", alignItems:"center", justifyContent:"center", padding:20, cursor:"pointer" }}>
          <img src={lightboxImg} alt="" style={{ maxWidth:"90vw", maxHeight:"90vh", borderRadius:12, objectFit:"contain", boxShadow:"0 20px 60px rgba(0,0,0,0.6)" }} />
          <button onClick={() => setLightboxImg(null)} style={{ position:"fixed", top:20, right:24, background:"rgba(255,255,255,0.15)", border:"none", color:"#fff", fontSize:28, cursor:"pointer", borderRadius:"50%", width:44, height:44 }}>✕</button>
        </div>
      )}

      {/* ══ FLOATING WHATSAPP BUTTON ══ */}
      <a href={WHATSAPP} target="_blank" rel="noopener noreferrer" className="wa-float" style={{ position:"fixed", bottom:24, right:24, background:"#25D366", color:"#fff", width:60, height:60, borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", fontSize:28, textDecoration:"none", boxShadow:"0 6px 24px rgba(37,211,102,0.6)", zIndex:998 }}>
        💬
      </a>
    </div>
  );
}