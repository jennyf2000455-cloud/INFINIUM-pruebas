import { useState } from "react";
import { base44 } from "@/api/base44Client";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    await base44.integrations.Core.SendEmail({
      to: "Info@ivoryshinecleaning.com",
      subject: `New Contact Message from ${form.name}`,
      body: `Name: ${form.name}\nEmail: ${form.email}\n\nMessage:\n${form.message}`,
    });
    setSubmitted(true);
    setSubmitting(false);
  };

  const inp = { width: "100%", padding: "12px 14px", border: "1.5px solid #DDD", borderRadius: 10, fontSize: 14, fontFamily: "inherit", outline: "none", boxSizing: "border-box", background: "#fff", color: "#1A1A1A" };

  return (
    <div style={{ fontFamily: "'Georgia', serif", background: "#FAFAF7", minHeight: "100vh", padding: "60px 24px" }}>
      <div style={{ maxWidth: 640, margin: "0 auto" }}>
        <h1 style={{ fontSize: "clamp(28px, 5vw, 48px)", fontWeight: 300, letterSpacing: "0.02em", color: "#1A1A1A", marginBottom: 24 }}>
          Contact Us
        </h1>
        <div style={{ width: 60, height: 2, background: "#C8A44D", marginBottom: 32 }} />

        {/* Contact methods */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginBottom: 40 }}>
          {[
            { icon: "📞", label: "Phone", value: "703-930-5056", href: "tel:7039305056" },
            { icon: "✉️", label: "Email", value: "Info@ivoryshinecleaning.com", href: "mailto:Info@ivoryshinecleaning.com" },
            { icon: "📍", label: "Service Area", value: "Virginia, USA", href: "https://maps.app.goo.gl/PsAWBULfnci7wEgDA?g_st=iw" },
            { icon: <svg width="22" height="22" viewBox="0 0 24 24" fill="#25D366"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>, label: "WhatsApp", value: "Message us on WhatsApp", href: "https://wa.me/17039305056?text=Hello%2C%20contacting%20from%20your%20website." },
          ].map(({ icon, label, value, href }) => (
            <a key={label} href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noreferrer"
              style={{ background: "#fff", borderRadius: 14, padding: "20px 16px", border: "1px solid #E8E4D8", textDecoration: "none", display: "block", textAlign: "center" }}>
              <div style={{ fontSize: 24, marginBottom: 8 }}>{icon}</div>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#2D5A27", letterSpacing: "0.1em", marginBottom: 4 }}>{label}</div>
              <div style={{ fontSize: 12, color: "#1A1A1A" }}>{value}</div>
            </a>
          ))}
        </div>

        {/* Contact form */}
        {submitted ? (
          <div style={{ background: "#F0FDF4", border: "1.5px solid #BBF7D0", borderRadius: 16, padding: "40px 32px", textAlign: "center" }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>✅</div>
            <h3 style={{ fontSize: 20, fontWeight: 600, color: "#1A1A1A", marginBottom: 8 }}>Message Sent!</h3>
            <p style={{ fontSize: 14, color: "#6B7280" }}>We'll get back to you within 24 hours.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} style={{ background: "#fff", borderRadius: 16, padding: "32px", border: "1px solid #E8E4D8" }}>
            <h3 style={{ fontSize: 18, fontWeight: 600, color: "#1A1A1A", marginBottom: 24, marginTop: 0 }}>Send Us a Message</h3>
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: "block", fontSize: 11, fontWeight: 700, color: "#1A1A1A", letterSpacing: "0.05em", marginBottom: 5 }}>Your Name *</label>
              <input required style={inp} value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Jane Smith" />
            </div>
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: "block", fontSize: 11, fontWeight: 700, color: "#1A1A1A", letterSpacing: "0.05em", marginBottom: 5 }}>Email Address *</label>
              <input required type="email" style={inp} value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="you@email.com" />
            </div>
            <div style={{ marginBottom: 24 }}>
              <label style={{ display: "block", fontSize: 11, fontWeight: 700, color: "#1A1A1A", letterSpacing: "0.05em", marginBottom: 5 }}>Message *</label>
              <textarea required rows={4} style={{ ...inp, resize: "vertical" }} value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} placeholder="How can we help you?" />
            </div>
            <button type="submit" disabled={submitting} style={{ width: "100%", background: submitting ? "#888" : "#2D5A27", color: "#fff", border: "none", borderRadius: 10, padding: "14px", fontSize: 14, fontWeight: 600, cursor: submitting ? "not-allowed" : "pointer", fontFamily: "inherit" }}>
              {submitting ? "Sending..." : "Send Message"}
            </button>
          </form>
        )}

        <div style={{ marginTop: 32 }}>
          <a href="/Home" style={{ color: "#2D5A27", textDecoration: "none", fontSize: 13 }}>← Back to Home</a>
        </div>
      </div>
    </div>
  );
}