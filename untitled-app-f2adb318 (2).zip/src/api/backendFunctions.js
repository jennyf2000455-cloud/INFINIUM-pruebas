import { base44 } from './base44Client';

export const submitLead = base44.functions.submitLead;
export const notify_new_lead_email = base44.functions.notify_new_lead_email;
