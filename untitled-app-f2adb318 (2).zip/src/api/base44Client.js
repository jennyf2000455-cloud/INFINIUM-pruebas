import { createClient } from '@base44/sdk';
import { appParams } from '@/lib/app-params';

const { token, functionsVersion, appBaseUrl } = appParams;

export const base44 = createClient({
  appId: "69f4e7f16a423661f2adb318",
  token,
  functionsVersion,
  requiresAuth: false,
  appBaseUrl
});