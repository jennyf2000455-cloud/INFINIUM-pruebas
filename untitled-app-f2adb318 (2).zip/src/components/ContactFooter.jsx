import React from 'react';
import { useLang } from './LanguageContext';

export default function ContactFooter() {
  const { lang, t } = useLang();

  return (
    <>
      {/* Contact Section */}
      <section id="contact" className="py-24 bg-ivory">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <p className="font-jost text-xs text-gold tracking-widest uppercase mb-3">Contact Us</p>
            <h2 className="font-cormorant text-4xl md:text-5xl font-semibold text-foreground mb-4">{t.contactTitle}</h2>
            <div className="w-16 h-px bg-gold mx-auto mt-6"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {/* Phone */}
            <a href="tel:7039305056" className="group bg-white rounded-2xl p-8 text-center border border-gold/10 hover:border-gold/40 hover:shadow-lg transition-all">
              <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-gold/10 flex items-center justify-center group-hover:bg-gold/20 transition-colors">
                <svg className="w-5 h-5 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
              </div>
              <p className="font-cormorant text-xl font-semibold text-foreground mb-1">703-930-5056</p>
              <p className="font-jost text-xs text-gold uppercase tracking-wider">{t.callNow}</p>
            </a>

            {/* Email */}
            <a href="mailto:Info@ivoryshinecleaning.com" className="group bg-white rounded-2xl p-8 text-center border border-gold/10 hover:border-gold/40 hover:shadow-lg transition-all">
              <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-gold/10 flex items-center justify-center group-hover:bg-gold/20 transition-colors">
                <svg className="w-5 h-5 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <p className="font-cormorant text-lg font-semibold text-foreground mb-1">Info@ivoryshinecleaning.com</p>
              <p className="font-jost text-xs text-gold uppercase tracking-wider">Email</p>
            </a>

            {/* Map */}
            <a href="https://maps.app.goo.gl/PsAWBULfnci7wEgDA?g_st=iw" target="_blank" rel="noopener noreferrer"
              className="group bg-white rounded-2xl p-8 text-center border border-gold/10 hover:border-gold/40 hover:shadow-lg transition-all">
              <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-gold/10 flex items-center justify-center group-hover:bg-gold/20 transition-colors">
                <svg className="w-5 h-5 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <p className="font-cormorant text-xl font-semibold text-foreground mb-1">Virginia, USA</p>
              <p className="font-jost text-xs text-gold uppercase tracking-wider">
                {lang === 'es' ? 'Ver en el mapa' : 'View on map'}
              </p>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-white py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-center md:text-left">
              <div className="flex items-center gap-3 justify-center md:justify-start mb-2">
                <img
                  src="https://media.base44.com/images/public/69f4e7f16a423661f2adb318/a90d5539e_logooficial.png"
                  alt="Ivory Shine Cleaning"
                  className="h-10 w-auto object-contain brightness-0 invert"
                />
              </div>
              <p className="font-jost text-xs text-white/50">{t.footerTag}</p>
            </div>

            <div className="text-center space-y-1">
              <p className="font-jost text-xs text-white/50 italic max-w-xs">{t.disclaimer2}</p>
            </div>

            <div className="text-center md:text-right">
              <p className="font-jost text-xs text-white/50">© {new Date().getFullYear()} Ivory Shine Cleaning LLC</p>
              <p className="font-jost text-xs text-white/30">{t.allRights}</p>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}