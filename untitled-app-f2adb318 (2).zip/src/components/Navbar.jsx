import React, { useState, useEffect } from 'react';
import { useLang } from './LanguageContext';

export default function Navbar() {
  const { lang, setLang, t } = useLang();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'bg-white/95 backdrop-blur-md shadow-sm' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <img
            src="https://media.base44.com/images/public/69f4e7f16a423661f2adb318/a90d5539e_logooficial.png"
            alt="Ivory Shine Cleaning"
            className="h-12 w-auto object-contain"
          />
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          <button onClick={() => scrollTo('services')} className="font-jost text-sm text-muted-foreground hover:text-gold transition-colors">{t.services}</button>
          <button onClick={() => scrollTo('about')} className="font-jost text-sm text-muted-foreground hover:text-gold transition-colors">{t.about}</button>
          <button onClick={() => scrollTo('contact')} className="font-jost text-sm text-muted-foreground hover:text-gold transition-colors">{t.contact}</button>

          {/* Language Toggle */}
          <div className="flex items-center gap-1 border border-gold/30 rounded-full px-1 py-0.5">
            <button onClick={() => setLang('en')} className={`text-xs px-2 py-0.5 rounded-full transition-all ${lang === 'en' ? 'bg-gold text-white' : 'text-muted-foreground hover:text-gold'}`}>EN</button>
            <button onClick={() => setLang('es')} className={`text-xs px-2 py-0.5 rounded-full transition-all ${lang === 'es' ? 'bg-gold text-white' : 'text-muted-foreground hover:text-gold'}`}>ES</button>
          </div>

          <button
            onClick={() => scrollTo('ivy')}
            className="gold-gradient text-white font-jost text-sm px-5 py-2 rounded-full hover:opacity-90 transition-opacity shadow-md"
          >
            {t.getEstimate}
          </button>
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden flex items-center gap-3">
          <div className="flex items-center gap-1 border border-gold/30 rounded-full px-1 py-0.5">
            <button onClick={() => setLang('en')} className={`text-xs px-2 py-0.5 rounded-full transition-all ${lang === 'en' ? 'bg-gold text-white' : 'text-muted-foreground'}`}>EN</button>
            <button onClick={() => setLang('es')} className={`text-xs px-2 py-0.5 rounded-full transition-all ${lang === 'es' ? 'bg-gold text-white' : 'text-muted-foreground'}`}>ES</button>
          </div>
          <button onClick={() => setMenuOpen(!menuOpen)} className="text-foreground p-1">
            <div className="w-5 space-y-1">
              <span className={`block h-0.5 bg-current transition-all ${menuOpen ? 'rotate-45 translate-y-1.5' : ''}`}></span>
              <span className={`block h-0.5 bg-current transition-all ${menuOpen ? 'opacity-0' : ''}`}></span>
              <span className={`block h-0.5 bg-current transition-all ${menuOpen ? '-rotate-45 -translate-y-1.5' : ''}`}></span>
            </div>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden bg-white border-t border-border px-6 py-4 space-y-4">
          <button onClick={() => scrollTo('services')} className="block font-jost text-sm text-muted-foreground hover:text-gold">{t.services}</button>
          <button onClick={() => scrollTo('about')} className="block font-jost text-sm text-muted-foreground hover:text-gold">{t.about}</button>
          <button onClick={() => scrollTo('contact')} className="block font-jost text-sm text-muted-foreground hover:text-gold">{t.contact}</button>
          <button onClick={() => scrollTo('ivy')} className="w-full gold-gradient text-white font-jost text-sm px-5 py-2 rounded-full">{t.getEstimate}</button>
        </div>
      )}
    </nav>
  );
}