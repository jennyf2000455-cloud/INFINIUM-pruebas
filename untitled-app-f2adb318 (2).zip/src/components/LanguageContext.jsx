import React, { createContext, useContext, useState } from 'react';

const LanguageContext = createContext();

export const translations = {
  en: {
    // Nav
    services: "Services",
    about: "About",
    contact: "Contact",
    getEstimate: "Get My Estimate",
    scheduleAppointment: "Schedule Appointment",
    callNow: "Call Now",
    // Hero
    headline: "Your Time Matters. We Clean.",
    subheadline: "Premium residential and commercial cleaning services in Virginia, designed to bring comfort, peace, and shine to every space.",
    // IVY
    ivyTitle: "Meet IVY, Your Cleaning Assistant",
    ivyWelcome: "Hi, I'm IVY, your Ivory Shine assistant. I'll ask you 3 quick questions to understand your cleaning needs and help you schedule your appointment.",
    q1: "What type of cleaning do you need?",
    q1_opt1: "Regular Home Cleaning",
    q1_opt2: "Deep Cleaning",
    q1_opt3: "Move-In / Move-Out Cleaning",
    q1_opt4: "Office / Commercial Cleaning",
    q2: "What size is the space?",
    q2_opt1: "Small space / Apartment",
    q2_opt2: "Medium Home",
    q2_opt3: "Large Home",
    q2_opt4: "Not Sure",
    q3: "When would you like to schedule?",
    q3_opt1: "As Soon As Possible",
    q3_opt2: "This Week",
    q3_opt3: "Next Week",
    q3_opt4: "I Want a Call First",
    ivyComplete: "Great! Based on your answers, Ivory Shine can help you with this cleaning. To give you an accurate quote and confirm availability, please schedule a quick appointment with our team.",
    disclaimer: "This is only an initial estimate. Final pricing depends on the condition of the property, exact size, requested details, and availability.",
    btnSchedule: "Schedule Appointment",
    btnRequestCall: "Request a Call",
    btnCallNow: "Call Now",
    btnSendMessage: "Send Message",
    btnUploadPhotos: "Upload Photos for Better Quote",
    // Appointment Form
    appointmentTitle: "Schedule Your Appointment",
    appointmentSub: "Fill out the form below and we'll confirm your availability.",
    fullName: "Full Name",
    phone: "Phone Number",
    email: "Email",
    preferredDate: "Preferred Date",
    preferredTime: "Preferred Time",
    address: "Address or ZIP Code",
    notes: "Cleaning Notes",
    uploadPhotos: "Upload Photos (Optional)",
    submit: "Request Appointment",
    successMsg: "Your appointment request has been received. Ivory Shine will contact you to confirm availability and final quote.",
    // Services
    servicesTitle: "Our Services",
    servicesSub: "Premium cleaning tailored to your needs",
    getEstimateBtn: "Get Estimate",
    // About
    aboutTitle: "Our Story",
    // Why Us
    whyTitle: "Why Choose Ivory Shine?",
    // Contact
    contactTitle: "Get In Touch",
    footerTag: "Premium Cleaning Services · Virginia, USA",
    allRights: "All rights reserved.",
    disclaimer2: "All estimates are preliminary. Final pricing may vary depending on property condition, exact size, requested details, location, and availability.",
  },
  es: {
    services: "Servicios",
    about: "Nosotros",
    contact: "Contacto",
    getEstimate: "Obtener Estimado",
    scheduleAppointment: "Agendar Cita",
    callNow: "Llamar Ahora",
    headline: "Tu Tiempo Importa. Nosotros Limpiamos.",
    subheadline: "Servicios premium de limpieza residencial y comercial en Virginia, diseñados para traer comodidad, paz y brillo a cada espacio.",
    ivyTitle: "Conoce a IVY, Tu Asistente de Limpieza",
    ivyWelcome: "Hola, soy IVY, tu asistente de Ivory Shine. Te haré 3 preguntas rápidas para entender tu limpieza y ayudarte a agendar tu cita.",
    q1: "¿Qué tipo de limpieza necesitas?",
    q1_opt1: "Limpieza regular del hogar",
    q1_opt2: "Limpieza profunda",
    q1_opt3: "Limpieza de mudanza / Move-In / Move-Out",
    q1_opt4: "Oficina / Comercial",
    q2: "¿Qué tamaño tiene el lugar?",
    q2_opt1: "Espacio pequeño / Apartamento",
    q2_opt2: "Casa mediana",
    q2_opt3: "Casa grande",
    q2_opt4: "No estoy seguro",
    q3: "¿Cuándo te gustaría agendar?",
    q3_opt1: "Lo antes posible",
    q3_opt2: "Esta semana",
    q3_opt3: "La próxima semana",
    q3_opt4: "Quiero una llamada primero",
    ivyComplete: "¡Perfecto! Según tus respuestas, Ivory Shine puede ayudarte con esta limpieza. Para darte una cotización exacta y confirmar disponibilidad, agenda una cita rápida con nuestro equipo.",
    disclaimer: "Este es solo un estimado inicial. El precio final depende de la condición de la propiedad, tamaño exacto, detalles solicitados y disponibilidad.",
    btnSchedule: "Agendar Cita",
    btnRequestCall: "Solicitar Llamada",
    btnCallNow: "Llamar Ahora",
    btnSendMessage: "Enviar Mensaje",
    btnUploadPhotos: "Subir Fotos para Mejor Estimado",
    appointmentTitle: "Agenda Tu Cita",
    appointmentSub: "Completa el formulario y confirmaremos tu disponibilidad.",
    fullName: "Nombre Completo",
    phone: "Número de Teléfono",
    email: "Correo Electrónico",
    preferredDate: "Fecha Preferida",
    preferredTime: "Hora Preferida",
    address: "Dirección o Código Postal",
    notes: "Notas de Limpieza",
    uploadPhotos: "Subir Fotos (Opcional)",
    submit: "Solicitar Cita",
    successMsg: "Tu solicitud de cita ha sido recibida. Ivory Shine se comunicará contigo para confirmar disponibilidad y cotización final.",
    servicesTitle: "Nuestros Servicios",
    servicesSub: "Limpieza premium adaptada a tus necesidades",
    getEstimateBtn: "Solicitar Estimado",
    aboutTitle: "Nuestra Historia",
    whyTitle: "¿Por Qué Elegir Ivory Shine?",
    contactTitle: "Contáctanos",
    footerTag: "Servicios Premium de Limpieza · Virginia, USA",
    allRights: "Todos los derechos reservados.",
    disclaimer2: "Todos los estimados son preliminares. El precio final puede variar según la condición de la propiedad, tamaño exacto, detalles solicitados, ubicación y disponibilidad.",
  }
};

export function LanguageProvider({ children }) {
  const [lang, setLang] = useState('en');
  const t = translations[lang];
  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLang() {
  return useContext(LanguageContext);
}