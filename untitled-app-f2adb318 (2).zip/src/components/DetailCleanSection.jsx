import React, { useState } from 'react';
import { useLang } from './LanguageContext';

const everyVisit = {
  en: [
    "Countertops and high-touch surfaces cleaned and sanitized",
    "Outside of range hood, top and front of range cleaned",
    "Drip pans or glass-top surfaces wiped",
    "Sinks cleaned and chrome shined",
    "Fronts of all appliances cleaned",
    "Floors vacuumed and damp-mopped",
    "Window sills, ledges, and blinds dusted",
    "Cobwebs removed",
    "Microwave cleaned inside and out",
    "Doors and door frames spot-cleaned",
    "General dusting",
    "Fronts of cabinets",
  ],
  es: [
    "Superficies y áreas de alto contacto limpiadas y sanitizadas",
    "Exterior de campana extractora y superficie del horno",
    "Quemadores o superficie de vitrocerámica",
    "Fregaderos limpios y accesorios brillantes",
    "Frentes de todos los electrodomésticos",
    "Pisos aspirados y trapeados",
    "Alféizares, repisas y persianas",
    "Remoción de telarañas",
    "Microondas limpiado por dentro y por fuera",
    "Puertas y marcos de puertas",
    "Desempolvado general",
    "Frentes de gabinetes",
  ]
};

const detailDay = {
  en: [
    "Inside of range hood cleaned",
    "Drip pans or glass-top surfaces deep cleaned",
    "Doors and door frames hand-wiped",
    "Appliances cleaned and shined",
    "Knickknack areas cleaned",
    "Fronts of cabinets hand-wiped",
    "Baseboards and window sills hand-wiped",
    "Floors given extra attention",
    "All kitchen furniture hand-wiped",
  ],
  es: [
    "Interior de la campana extractora",
    "Quemadores o superficie de vitrocerámica profunda",
    "Puertas y marcos limpiados a mano",
    "Electrodomésticos brillantes",
    "Áreas de decoración",
    "Frentes de gabinetes a mano",
    "Zócalos y alféizares a mano",
    "Pisos con atención extra",
    "Todos los muebles de cocina a mano",
  ]
};

export default function DetailCleanSection() {
  const { lang } = useLang();
  const [tab, setTab] = useState('every');

  return (
    <section className="py-24 bg-gradient-to-b from-ivory to-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <p className="font-jost text-xs text-gold tracking-widest uppercase mb-3">Exclusive System</p>
          <h2 className="font-cormorant text-4xl md:text-5xl font-semibold text-foreground mb-4">
            The Detail-Clean Rotation System<sup className="text-2xl">®</sup>
          </h2>
          <div className="w-16 h-px bg-gold mx-auto my-6"></div>
          <p className="font-jost text-sm text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            {lang === 'es'
              ? 'Nuestro sistema exclusivo está diseñado para mantener un alto nivel de limpieza en el hogar de manera constante. Para clientes con servicio semanal o quincenal, Ivory Shine aplica este sistema para asegurar que el hogar se mantenga limpio y bien mantenido.'
              : 'Our Exclusive Detail-Clean Rotation System® is designed to maintain a high level of cleanliness in your home on a consistent basis. For clients scheduled on a weekly or biweekly basis, Ivory Shine applies the Detail-Clean Rotation System® to ensure the home stays consistently clean and well-maintained.'
            }
          </p>
        </div>

        {/* Tab selector */}
        <div className="flex items-center justify-center gap-3 mb-10">
          <button
            onClick={() => setTab('every')}
            className={`font-jost text-sm px-6 py-2.5 rounded-full transition-all ${tab === 'every' ? 'gold-gradient text-white shadow-md' : 'border border-gold/40 text-gold hover:bg-gold/5'}`}
          >
            {lang === 'es' ? 'Cada Visita' : 'Every Visit'}
          </button>
          <button
            onClick={() => setTab('detail')}
            className={`font-jost text-sm px-6 py-2.5 rounded-full transition-all ${tab === 'detail' ? 'gold-gradient text-white shadow-md' : 'border border-gold/40 text-gold hover:bg-gold/5'}`}
          >
            {lang === 'es' ? 'Día de Rotación' : 'Detail Rotation Day'}
          </button>
        </div>

        <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-3">
          {(tab === 'every' ? everyVisit[lang] : detailDay[lang]).map((item, i) => (
            <div key={i} className="flex items-start gap-3 bg-white rounded-xl px-4 py-3 shadow-sm border border-gold/10">
              <div className="w-5 h-5 rounded-full bg-gold/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                <div className="w-1.5 h-1.5 rounded-full bg-gold"></div>
              </div>
              <p className="font-jost text-xs text-muted-foreground leading-relaxed">{item}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}