import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const IVY_IMG = "https://media.base44.com/images/public/69f4e671caaf925632125ab5/b7f5aa49d_ChatGPTImage1may202604_13_31am.png";

const IvyAvatar = ({ pulse = false }) => (
  <div className="relative w-28 h-28 mx-auto mb-3">
    <div className={pulse ? "ivy-float w-28 h-28" : "w-28 h-28"}>
      <img src={IVY_IMG} alt="IVY Assistant" className="w-28 h-28 object-contain drop-shadow-xl" />
    </div>
    <div className="absolute bottom-0 right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white shadow-sm animate-pulse"></div>
  </div>
);

const OptionButton = ({ label, sublabel, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className="w-full text-left px-4 py-3 rounded-xl border border-gold/30 bg-white hover:bg-gold/5 hover:border-gold text-sm font-jost text-foreground transition-all duration-200 group"
  >
    <span className="flex items-center gap-2">
      <span className="w-1.5 h-1.5 rounded-full bg-gold/40 group-hover:bg-gold transition-colors flex-shrink-0"></span>
      <span>
        <span className="block font-medium">{label}</span>
        {sublabel && <span className="block text-xs text-muted-foreground mt-0.5">{sublabel}</span>}
      </span>
    </span>
  </button>
);

export default function IvyBot({ onSchedule, onSave, lang = 'en' }) {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState({
    cleaning_type: '',
    space_size: '',
    desired_schedule: '',
    full_name: '',
    phone: '',
    email: '',
  });
  const [formError, setFormError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const isEn = lang === 'en';

  const q1Options = [
    { value: 'Regular Home Cleaning',  label: isEn ? 'Regular Home Cleaning'       : 'Limpieza Regular del Hogar',  sublabel: isEn ? 'Weekly / biweekly maintenance'    : 'Mantenimiento semanal / quincenal' },
    { value: 'Deep Cleaning',          label: isEn ? 'Deep Cleaning'                : 'Limpieza Profunda',           sublabel: isEn ? 'Detailed top-to-bottom clean'     : 'Limpieza detallada de arriba a abajo' },
    { value: 'Move-In / Move-Out',     label: isEn ? 'Move-In / Move-Out Cleaning'  : 'Mudanza / Move-In / Move-Out',sublabel: isEn ? 'For new or vacated homes'         : 'Para casas nuevas o que se desocupan' },
    { value: 'Office / Commercial',    label: isEn ? 'Office / Commercial Cleaning' : 'Oficina / Comercial',         sublabel: isEn ? 'Workspaces & commercial units'    : 'Espacios de trabajo y locales' },
  ];

  const q2Options = [
    { value: 'Studio / Small Apartment', label: isEn ? 'Studio / Small Apartment'  : 'Estudio / Apartamento pequeño', sublabel: isEn ? 'Up to 2 bed / 1 bath'    : 'Hasta 2 cuartos / 1 baño' },
    { value: 'Medium Home',              label: isEn ? 'Medium Home'               : 'Casa Mediana',                  sublabel: isEn ? '3–4 bed / 2 bath'        : '3–4 cuartos / 2 baños' },
    { value: 'Large Home',               label: isEn ? 'Large Home'                : 'Casa Grande',                  sublabel: isEn ? '5+ bed / 3+ bath'        : '5+ cuartos / 3+ baños' },
    { value: 'Commercial Space',         label: isEn ? 'Commercial / Office Space'  : 'Local / Oficina Comercial',    sublabel: isEn ? 'Office, retail, or studio': 'Oficina, local o estudio' },
  ];

  const q3Options = [
    { value: 'As Soon As Possible', label: isEn ? 'As Soon As Possible'    : 'Lo antes posible',      sublabel: isEn ? 'Within 48–72 hours'           : 'En 48–72 horas' },
    { value: 'This Week',           label: isEn ? 'This Week'              : 'Esta semana',           sublabel: isEn ? 'Flexible on exact day/time'    : 'Flexible en día y hora' },
    { value: 'Next Week',           label: isEn ? 'Next Week'              : 'La próxima semana',     sublabel: isEn ? 'Planning ahead'               : 'Planificando con anticipación' },
    { value: 'Call Me First',       label: isEn ? "I'd Like a Call First"  : 'Prefiero una llamada',  sublabel: isEn ? "We'll call to confirm details" : 'Los llamamos para confirmar detalles' },
  ];

  const handleQ1 = (val) => { setAnswers(a => ({ ...a, cleaning_type: val })); setStep(2); };
  const handleQ2 = (val) => { setAnswers(a => ({ ...a, space_size: val })); setStep(3); };
  const handleQ3 = (val) => { setAnswers(a => ({ ...a, desired_schedule: val })); setStep(4); };

  const handleContact = async () => {
    if (!answers.full_name.trim() || !answers.phone.trim()) {
      setFormError(isEn ? 'Name and phone are required.' : 'Nombre y teléfono son requeridos.');
      return;
    }
    setFormError('');
    setSubmitting(true);
    try {
      if (onSave) await onSave(answers);
    } catch(e) {
      console.error(e);
    }
    setSubmitting(false);
    setStep(5);
  };

  const stepIndicator = step > 0 && step < 4 ? (
    <div className="flex items-center gap-1.5 mb-4">
      {[1, 2, 3].map(s => (
        <div key={s} className={`h-1 flex-1 rounded-full transition-all duration-500 ${step >= s ? 'bg-gold' : 'bg-gold/20'}`}></div>
      ))}
      <span className="text-xs text-muted-foreground font-jost ml-1">{step}/3</span>
    </div>
  ) : null;

  return (
    <div className="bg-white rounded-3xl shadow-2xl border border-gold/20 overflow-hidden max-w-md w-full">
      <div className="bg-gradient-to-br from-ivory to-[#F0EDE5] px-6 pt-6 pb-4 text-center border-b border-gold/10">
        <IvyAvatar pulse={step === 0} />
        <h3 className="font-cormorant text-2xl font-semibold text-foreground">IVY</h3>
        <p className="font-jost text-xs text-gold tracking-widest uppercase mt-0.5">Ivory Shine Assistant</p>
      </div>

      <div className="px-6 py-6">
        {stepIndicator}
        <AnimatePresence mode="wait">

          {step === 0 && (
            <motion.div key="welcome" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <div className="bg-ivory rounded-2xl p-4 mb-5">
                <p className="font-jost text-sm text-foreground leading-relaxed">
                  {isEn
                    ? "Hi! I'm IVY 👋 I'll ask you 3 quick questions so our team can prepare a personalized quote for your space. Takes less than a minute!"
                    : "¡Hola! Soy IVY 👋 Te haré 3 preguntas rápidas para que nuestro equipo prepare una cotización personalizada para tu espacio. ¡Menos de un minuto!"}
                </p>
              </div>
              <button type="button" onClick={() => setStep(1)} className="w-full gold-gradient text-white font-jost text-sm py-3 rounded-xl hover:opacity-90 transition-opacity shadow-md">
                {isEn ? "Let's Get Started →" : "Comenzar →"}
              </button>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div key="q1" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <p className="font-cormorant text-xl font-semibold text-foreground mb-1">{isEn ? 'What type of cleaning do you need?' : '¿Qué tipo de limpieza necesitas?'}</p>
              <p className="font-jost text-xs text-muted-foreground mb-4">{isEn ? 'Select the option that best fits your situation.' : 'Selecciona la opción que mejor describe tu situación.'}</p>
              <div className="space-y-2">{q1Options.map(o => <OptionButton key={o.value} label={o.label} sublabel={o.sublabel} onClick={() => handleQ1(o.value)} />)}</div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="q2" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <p className="font-cormorant text-xl font-semibold text-foreground mb-1">{isEn ? 'How big is your space?' : '¿Qué tan grande es tu espacio?'}</p>
              <p className="font-jost text-xs text-muted-foreground mb-4">{isEn ? 'This helps us estimate the scope of the service.' : 'Esto nos ayuda a estimar el alcance del servicio.'}</p>
              <div className="space-y-2">{q2Options.map(o => <OptionButton key={o.value} label={o.label} sublabel={o.sublabel} onClick={() => handleQ2(o.value)} />)}</div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="q3" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <p className="font-cormorant text-xl font-semibold text-foreground mb-1">{isEn ? 'When do you need the service?' : '¿Cuándo necesitas el servicio?'}</p>
              <p className="font-jost text-xs text-muted-foreground mb-4">{isEn ? "We'll do our best to match your preferred timing." : 'Haremos lo posible por adaptarnos a tu horario.'}</p>
              <div className="space-y-2">{q3Options.map(o => <OptionButton key={o.value} label={o.label} sublabel={o.sublabel} onClick={() => handleQ3(o.value)} />)}</div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div key="quote" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <div className="bg-gradient-to-br from-[#0F2410] to-[#2D5A27] rounded-2xl p-5 mb-5 text-center">
                <p className="text-gold font-jost text-xs tracking-widest uppercase mb-2">{isEn ? 'Your Estimate Is Ready' : 'Tu Estimado Está Listo'}</p>
                <p className="text-white font-cormorant text-3xl font-semibold mb-1">$200+</p>
                <p className="text-white/70 font-jost text-xs leading-relaxed">
                  {isEn
                    ? "Based on your selections, your service investment starts at $200. The exact quote depends on your space's current condition — and it's worth every penny. ✨"
                    : "Según tus respuestas, tu inversión comienza desde $200. La cotización exacta depende del estado actual de tu espacio — y vale cada centavo. ✨"}
                </p>
              </div>
              <p className="font-cormorant text-lg font-semibold text-foreground mb-1">{isEn ? 'Want your exact quote?' : '¿Quieres tu cotización exacta?'}</p>
              <p className="font-jost text-xs text-muted-foreground mb-4">
                {isEn
                  ? "Leave your name and phone — our team will call you in under 24 hours with a tailored number just for your home."
                  : "Deja tu nombre y teléfono — nuestro equipo te llamará en menos de 24 horas con un número personalizado solo para tu hogar."}
              </p>
              <div className="space-y-3">
                <input type="text" placeholder={isEn ? 'Your full name *' : 'Tu nombre completo *'} value={answers.full_name} onChange={e => setAnswers(a => ({ ...a, full_name: e.target.value }))} className="w-full px-4 py-3 rounded-xl border border-gold/30 bg-white text-sm font-jost focus:outline-none focus:border-gold" />
                <input type="tel" placeholder={isEn ? 'Phone number *' : 'Número de teléfono *'} value={answers.phone} onChange={e => setAnswers(a => ({ ...a, phone: e.target.value }))} className="w-full px-4 py-3 rounded-xl border border-gold/30 bg-white text-sm font-jost focus:outline-none focus:border-gold" />
                <input type="email" placeholder={isEn ? 'Email (optional)' : 'Correo electrónico (opcional)'} value={answers.email} onChange={e => setAnswers(a => ({ ...a, email: e.target.value }))} className="w-full px-4 py-3 rounded-xl border border-gold/30 bg-white text-sm font-jost focus:outline-none focus:border-gold" />
                {formError && <p className="text-red-500 text-xs font-jost">{formError}</p>}
                <button type="button" onClick={handleContact} disabled={submitting} className="w-full gold-gradient text-white font-jost text-sm py-3 rounded-xl hover:opacity-90 transition-opacity shadow-md disabled:opacity-60">
                  {submitting ? (isEn ? 'Sending...' : 'Enviando...') : (isEn ? 'Get My Exact Quote →' : 'Obtener Mi Cotización Exacta →')}
                </button>
              </div>
              <p className="font-jost text-xs text-muted-foreground italic mt-3 text-center">{isEn ? '🔒 Your info is private. No spam, ever.' : '🔒 Tu información es privada. Sin spam, jamás.'}</p>
            </motion.div>
          )}

          {step === 5 && (
            <motion.div key="done" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
              <div className="text-center mb-5">
                <div className="text-4xl mb-3">✨</div>
                <p className="font-cormorant text-2xl font-semibold text-foreground mb-2">{isEn ? "You're on the list!" : '¡Ya estás en la lista!'}</p>
                <p className="font-jost text-sm text-muted-foreground leading-relaxed">
                  {isEn
                    ? `Perfect, ${answers.full_name.split(' ')[0]}! Our team will call you shortly to confirm your quote. Ivory Shine services start at $200 — because quality is never an accident.`
                    : `¡Perfecto, ${answers.full_name.split(' ')[0]}! Nuestro equipo te llamará pronto para confirmar tu cotización. Los servicios de Ivory Shine comienzan desde $200 — porque la calidad nunca es un accidente.`}
                </p>
              </div>
              <div className="space-y-2">
                <a href="tel:7039305056" className="w-full flex justify-center items-center gap-2 bg-[#2D5A27] text-white font-jost text-sm py-3 rounded-xl hover:opacity-90 transition-opacity shadow-md">
                  📞 {isEn ? 'Call Us Now: 703-930-5056' : 'Llámanos: 703-930-5056'}
                </a>
                <a href={`https://wa.me/17039305056?text=${encodeURIComponent(isEn ? `Hi! I just filled out IVY's form. My name is ${answers.full_name} and I'm interested in ${answers.cleaning_type}.` : `¡Hola! Acabo de llenar el formulario de IVY. Mi nombre es ${answers.full_name} y me interesa ${answers.cleaning_type}.`)}`} target="_blank" rel="noopener noreferrer" className="w-full flex justify-center items-center gap-2 border border-green-500/40 text-green-700 font-jost text-sm py-3 rounded-xl hover:bg-green-50 transition-colors">
                  💬 {isEn ? 'Message on WhatsApp' : 'Mensaje por WhatsApp'}
                </a>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  );
}