import { useState } from "react";

const PORTFOLIO_PHOTOS = [
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/8448395fc_ejemplo4.jpg", label_en: "Kitchen", label_es: "Cocina" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/e0d79172b_ejemplo5.jpg", label_en: "Dining Room", label_es: "Comedor" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/0b1e77a2b_ejemplo8.jpg", label_en: "Grand Entrance", label_es: "Entrada Principal" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/a71ce0f8e_ejemplo17.jpg", label_en: "Living Room", label_es: "Sala de Estar" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/7d35bbf8f_ejemplo19.jpg", label_en: "Master Bedroom", label_es: "Habitación Principal" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/a607faf1c_ejemplo23.jpg", label_en: "Bedroom", label_es: "Habitación" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/7c4a2913e_ejemplo24.jpg", label_en: "Bedroom", label_es: "Habitación" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/a7ce2c0ed_ejemplo26.jpg", label_en: "Kids Room", label_es: "Cuarto Infantil" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/3527cb53e_ejemplo28.jpg", label_en: "Sitting Room", label_es: "Sala de Lectura" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/73a5bda0e_ejemplo29.jpg", label_en: "Kitchen & Dining", label_es: "Cocina y Comedor" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/0cf24a87a_ejemplo34.jpg", label_en: "Bedroom", label_es: "Habitación" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/fcbda6cbb_ejemplo35.jpg", label_en: "Family Room", label_es: "Sala Familiar" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/16f88073e_ejemplo38.jpg", label_en: "Dining Room", label_es: "Comedor" },
  { url: "https://media.base44.com/images/public/69f4e7f16a423661f2adb318/7d908a992_ejemplo43.jpg", label_en: "Sun Room", label_es: "Sala de Sol" },
];

const COLORS = {
  gold: "#C8A44D",
  green: "#2D5A27",
  greenDeep: "#0F2410",
  lime: "#8BC34A",
  dark: "#1A1A1A",
  ivory: "#FAFAF7",
  gray: "#6B7280",
};

export default function PortfolioSection({ lang = "en" }) {
  const [lightbox, setLightbox] = useState(null);
  const [visibleCount, setVisibleCount] = useState(8);

  const visible = PORTFOLIO_PHOTOS.slice(0, visibleCount);
  const hasMore = visibleCount < PORTFOLIO_PHOTOS.length;

  return (
    <section id="portfolio-section" style={{ padding: "80px 24px", background: "#fff" }}>
      <style>{`
        .port-card { transition: transform 0.25s, box-shadow 0.25s; cursor: pointer; }
        .port-card:hover { transform: scale(1.03); box-shadow: 0 16px 40px rgba(0,0,0,0.22) !important; }
        .port-overlay { opacity: 0; transition: opacity 0.25s; }
        .port-card:hover .port-overlay { opacity: 1; }
        @media(max-width:768px){ .port-grid { grid-template-columns: 1fr 1fr !important; } }
        @media(max-width:480px){ .port-grid { grid-template-columns: 1fr !important; } }
      `}</style>

      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 52 }}>
          <div style={{ display: "inline-block", background: COLORS.gold + "18", border: `1px solid ${COLORS.gold}45`, borderRadius: 20, padding: "6px 20px", marginBottom: 16, fontSize: 11, letterSpacing: "0.14em", color: COLORS.gold, fontWeight: 700 }}>
            ✦ OUR PORTFOLIO ✦
          </div>
          <h2 style={{ fontSize: "clamp(26px,4vw,42px)", fontWeight: 300, letterSpacing: "0.02em", margin: "0 0 12px", color: COLORS.dark, fontFamily: "Georgia, serif" }}>
            {lang === "es" ? "Hogares Que Brillan" : "Homes That Shine"}
          </h2>
          <p style={{ color: COLORS.gray, fontSize: 15, maxWidth: 540, margin: "0 auto", lineHeight: 1.7 }}>
            {lang === "es"
              ? "Cada espacio que limpiamos refleja nuestro compromiso con la excelencia y el detalle."
              : "Every space we clean reflects our commitment to excellence and attention to detail."}
          </p>
          <div style={{ width: 60, height: 2, background: COLORS.gold, margin: "20px auto 0" }} />
        </div>

        {/* Featured first photo — large */}
        <div
          className="port-card"
          onClick={() => setLightbox(PORTFOLIO_PHOTOS[0])}
          style={{ borderRadius: 20, overflow: "hidden", position: "relative", marginBottom: 20, height: 420, boxShadow: "0 8px 32px rgba(0,0,0,0.12)" }}
        >
          <img src={PORTFOLIO_PHOTOS[0].url} alt={PORTFOLIO_PHOTOS[0][`label_${lang}`]} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center" }} />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(10,28,8,0.65) 0%, transparent 55%)" }} />
          <div className="port-overlay" style={{ position: "absolute", inset: 0, background: "rgba(200,164,77,0.1)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ width: 56, height: 56, borderRadius: "50%", background: "rgba(255,255,255,0.9)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>🔍</div>
          </div>
          <div style={{ position: "absolute", bottom: 24, left: 28 }}>
            <span style={{ background: COLORS.gold, color: COLORS.dark, borderRadius: 20, padding: "5px 14px", fontSize: 11, fontWeight: 800, letterSpacing: "0.08em" }}>
              ⭐ {lang === "es" ? "RESULTADO REAL" : "REAL RESULT"}
            </span>
            <div style={{ color: "#fff", fontSize: 22, fontWeight: 700, marginTop: 8, textShadow: "0 2px 8px rgba(0,0,0,0.5)", fontFamily: "Georgia, serif" }}>
              {PORTFOLIO_PHOTOS[0][`label_${lang}`]}
            </div>
          </div>
        </div>

        {/* Grid */}
        <div className="port-grid" style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
          {visible.slice(1).map((photo, i) => (
            <div
              key={i}
              className="port-card"
              onClick={() => setLightbox(photo)}
              style={{ borderRadius: 16, overflow: "hidden", position: "relative", aspectRatio: "4/3", boxShadow: "0 4px 16px rgba(0,0,0,0.1)" }}
            >
              <img src={photo.url} alt={photo[`label_${lang}`]} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(10,28,8,0.6) 0%, transparent 50%)" }} />
              <div className="port-overlay" style={{ position: "absolute", inset: 0, background: "rgba(200,164,77,0.08)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <div style={{ width: 40, height: 40, borderRadius: "50%", background: "rgba(255,255,255,0.85)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🔍</div>
              </div>
              <div style={{ position: "absolute", bottom: 12, left: 12, right: 12 }}>
                <div style={{ background: COLORS.gold, color: COLORS.dark, borderRadius: 12, padding: "3px 10px", fontSize: 10, fontWeight: 700, display: "inline-block" }}>
                  ✦ {photo[`label_${lang}`]}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Load more */}
        {hasMore && (
          <div style={{ textAlign: "center", marginTop: 36 }}>
            <button
              onClick={() => setVisibleCount(PORTFOLIO_PHOTOS.length)}
              style={{ background: "transparent", color: COLORS.green, border: `2px solid ${COLORS.green}`, borderRadius: 12, padding: "13px 36px", cursor: "pointer", fontSize: 14, fontWeight: 600, fontFamily: "inherit", transition: "all 0.2s" }}
              onMouseEnter={e => { e.currentTarget.style.background = COLORS.green; e.currentTarget.style.color = "#fff"; }}
              onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = COLORS.green; }}
            >
              {lang === "es" ? `Ver todas las fotos (${PORTFOLIO_PHOTOS.length})` : `View all photos (${PORTFOLIO_PHOTOS.length})`} →
            </button>
          </div>
        )}

        {/* Stats bar */}
        <div style={{ display: "flex", justifyContent: "center", gap: 48, marginTop: 52, padding: "28px 32px", background: COLORS.greenDeep, borderRadius: 18, flexWrap: "wrap" }}>
          {[
            ["200+", lang === "es" ? "Clientes Felices" : "Happy Clients"],
            ["10+", lang === "es" ? "Años de Experiencia" : "Years of Experience"],
            ["5.0★", lang === "es" ? "Calificación" : "Rating"],
            ["100%", lang === "es" ? "Satisfacción" : "Satisfaction"],
          ].map(([val, label]) => (
            <div key={label} style={{ textAlign: "center" }}>
              <div style={{ fontSize: 28, fontWeight: 800, color: COLORS.gold, fontFamily: "Georgia, serif" }}>{val}</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.6)", letterSpacing: "0.06em", marginTop: 3 }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div
          onClick={() => setLightbox(null)}
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.93)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}
        >
          <button onClick={() => setLightbox(null)} style={{ position: "absolute", top: 20, right: 24, background: "none", border: "none", color: "#fff", fontSize: 32, cursor: "pointer", lineHeight: 1 }}>✕</button>
          <div style={{ textAlign: "center" }}>
            <img
              src={lightbox.url}
              alt={lightbox[`label_${lang}`]}
              style={{ maxWidth: "88vw", maxHeight: "82vh", borderRadius: 14, objectFit: "contain", boxShadow: "0 8px 60px rgba(0,0,0,0.7)" }}
              onClick={e => e.stopPropagation()}
            />
            <div style={{ color: "#fff", marginTop: 14, fontSize: 16, fontFamily: "Georgia, serif", opacity: 0.85 }}>
              {lightbox[`label_${lang}`]}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}