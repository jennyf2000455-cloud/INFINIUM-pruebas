import React from 'react';
import { useLang } from './LanguageContext';

export default function AboutSection() {
  const { lang } = useLang();

  const whyItems = lang === 'es' ? [
    "Más de 10 años de experiencia",
    "Servicio confiable y profesional",
    "Limpieza orientada al detalle",
    "Servicios residenciales y comerciales",
    "Tranquilidad para cada cliente",
    "Servicio premium con atención personal",
  ] : [
    "Over 10 years of experience",
    "Reliable and professional service",
    "Detail-oriented cleaning",
    "Residential and commercial services",
    "Peace of mind for every client",
    "Premium service with personal care",
  ];

  return (
    <>
      {/* About Section */}
      <section id="about" className="py-24 bg-ivory">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <p className="font-jost text-xs text-gold tracking-widest uppercase mb-3">Our Story</p>
              <h2 className="font-cormorant text-4xl md:text-5xl font-semibold text-foreground mb-6">
                {lang === 'es' ? 'Nuestra Historia' : 'About Ivory Shine'}
              </h2>
              <div className="w-12 h-px bg-gold mb-8"></div>

              {lang === 'es' ? (
                <div className="space-y-4 font-jost text-sm text-muted-foreground leading-relaxed">
                  <p>Ivory Shine Cleaning es una empresa de limpieza profesional y orientada al detalle con más de 10 años de experiencia en limpieza residencial y comercial.</p>
                  <p>Detrás de esta empresa hay una historia de dedicación, crecimiento y pasión. Soy originario de Guatemala, donde trabajé como profesor, un puesto que formó mis valores de responsabilidad, puntualidad y atención al detalle.</p>
                  <p>Cuando llegué a los Estados Unidos, comencé limpiando casas como una oportunidad para seguir adelante. Con el tiempo descubrí una verdadera pasión por transformar espacios y ver la satisfacción de los clientes al entrar en un ambiente limpio y fresco.</p>
                  <blockquote className="border-l-2 border-gold pl-4 italic text-foreground font-cormorant text-lg">
                    "En Ivory Shine Cleaning, no solo limpiamos, nos preocupamos. Cada hogar es tratado con dedicación, respeto y compromiso con la excelencia."
                  </blockquote>
                </div>
              ) : (
                <div className="space-y-4 font-jost text-sm text-muted-foreground leading-relaxed">
                  <p>Ivory Shine Cleaning is a detail-oriented cleaning company with over 10 years of experience. The company is committed to delivering high-quality service, professionalism, and trust in every home and business served.</p>
                  <p>The business was created with the vision of building a professional and growing cleaning company focused on excellence, attention to detail, and client satisfaction. What started as a personal service has grown into a structured business providing reliable, high-end cleaning services in Virginia.</p>
                  <blockquote className="border-l-2 border-gold pl-4 italic text-foreground font-cormorant text-lg">
                    "At Ivory Shine Cleaning, we don't just clean — we care. Every home is treated with dedication, respect, and commitment to excellence."
                  </blockquote>
                </div>
              )}
            </div>

            {/* Stats / Visual */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white rounded-2xl p-8 text-center shadow-sm border border-gold/10">
                <p className="font-cormorant text-5xl font-bold text-gold">10+</p>
                <p className="font-jost text-xs text-muted-foreground mt-2 uppercase tracking-wider">
                  {lang === 'es' ? 'Años de experiencia' : 'Years of experience'}
                </p>
              </div>
              <div className="bg-white rounded-2xl p-8 text-center shadow-sm border border-gold/10">
                <p className="font-cormorant text-5xl font-bold text-olive">100%</p>
                <p className="font-jost text-xs text-muted-foreground mt-2 uppercase tracking-wider">
                  {lang === 'es' ? 'Compromiso' : 'Committed'}
                </p>
              </div>
              <div className="bg-white rounded-2xl p-8 text-center shadow-sm border border-gold/10 col-span-2">
                <p className="font-cormorant text-3xl font-semibold text-foreground mb-2">Virginia, USA</p>
                <p className="font-jost text-xs text-muted-foreground uppercase tracking-wider">
                  {lang === 'es' ? 'Área de Servicio' : 'Service Area'}
                </p>
                <a
                  href="https://maps.app.goo.gl/PsAWBULfnci7wEgDA?g_st=iw"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block mt-3 font-jost text-xs text-gold border border-gold/40 px-4 py-1.5 rounded-full hover:bg-gold hover:text-white transition-all"
                >
                  {lang === 'es' ? 'Ver en el mapa' : 'View on map'}
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section id="why" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <p className="font-jost text-xs text-gold tracking-widest uppercase mb-3">Our Promise</p>
            <h2 className="font-cormorant text-4xl md:text-5xl font-semibold text-foreground mb-4">
              {lang === 'es' ? '¿Por Qué Elegir Ivory Shine?' : 'Why Choose Ivory Shine?'}
            </h2>
            <div className="w-16 h-px bg-gold mx-auto mt-6"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {whyItems.map((item, i) => (
              <div key={i} className="flex items-start gap-3 bg-ivory rounded-xl p-5 border border-gold/10">
                <div className="w-6 h-6 rounded-full gold-gradient flex items-center justify-center flex-shrink-0 mt-0.5">
                  <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <p className="font-jost text-sm text-foreground">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}