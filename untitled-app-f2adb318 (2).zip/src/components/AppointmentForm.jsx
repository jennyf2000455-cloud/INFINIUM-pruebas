import React, { useState } from 'react';
import { useLang } from './LanguageContext';
import { motion } from 'framer-motion';

export default function AppointmentForm({ ivyAnswers }) {
  const { t, lang } = useLang();
  const [form, setForm] = useState({
    full_name: '', phone: '', email: '',
    preferred_date: '', preferred_time: '', address: '', notes: ''
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.full_name || !form.phone) {
      setError(lang === 'es' ? 'Por favor ingresa tu nombre y teléfono.' : 'Please enter your name and phone number.');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const payload = {
        full_name: form.full_name,
        phone: form.phone,
        email: form.email || '',
        address_zip: form.address || '',
        notes: form.notes || '',
        preferred_date: form.preferred_date || '',
        preferred_time: form.preferred_time || '',
        cleaning_type: ivyAnswers?.cleaning_type || '',
        space_size: ivyAnswers?.space_size || '',
        desired_schedule: ivyAnswers?.desired_schedule || '',
        lead_source: ivyAnswers?.cleaning_type ? 'IVY Bot' : 'Website Form',
        status: 'New',
      };
      const res = await fetch('https://ivory-shine-cleaning.base44.app/api/apps/69f4e671caaf925632125ab5/functions/createLead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Submit failed');
      setSuccess(true);
      await fetch('/api/functions/notifyLead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } catch (err) {
      setError(lang === 'es' ? 'Algo salió mal. Llama al 703-930-5056.' : 'Something went wrong. Call 703-930-5056.');
    }
    setLoading(false);
  };

  const inputClass = "w-full border border-border rounded-xl px-4 py-3 font-jost text-sm focus:outline-none focus:border-gold transition-colors bg-white";
  const labelClass = "block font-jost text-xs uppercase tracking-wider text-muted-foreground mb-1.5";

  if (success) {
    return (
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-12 px-6">
        <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gold/10 flex items-center justify-center">
          <svg className="w-8 h-8 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h3 className="font-cormorant text-2xl font-semibold text-foreground mb-3">
          {lang === 'es' ? '¡Solicitud Enviada!' : 'Request Received!'}
        </h3>
        <p className="font-jost text-sm text-muted-foreground leading-relaxed max-w-sm mx-auto">{t.successMsg}</p>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div>
          <label className={labelClass}>{t.fullName} *</label>
          <input required className={inputClass} value={form.full_name} onChange={e => set('full_name', e.target.value)} placeholder="Jane Smith" />
        </div>
        <div>
          <label className={labelClass}>{t.phone} *</label>
          <input required className={inputClass} value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="(703) 000-0000" />
        </div>
        <div>
          <label className={labelClass}>{t.email}</label>
          <input type="email" className={inputClass} value={form.email} onChange={e => set('email', e.target.value)} placeholder="you@email.com" />
        </div>
        <div>
          <label className={labelClass}>{t.address}</label>
          <input className={inputClass} value={form.address} onChange={e => set('address', e.target.value)} placeholder="Virginia, VA 00000" />
        </div>
        <div>
          <label className={labelClass}>{t.preferredDate}</label>
          <input type="date" className={inputClass} value={form.preferred_date} onChange={e => set('preferred_date', e.target.value)} />
        </div>
        <div>
          <label className={labelClass}>{t.preferredTime}</label>
          <select className={inputClass} value={form.preferred_time} onChange={e => set('preferred_time', e.target.value)}>
            <option value="">{lang === 'es' ? 'Seleccionar hora...' : 'Select time...'}</option>
            <option value="8:00 AM">8:00 AM</option>
            <option value="9:00 AM">9:00 AM</option>
            <option value="10:00 AM">10:00 AM</option>
            <option value="11:00 AM">11:00 AM</option>
            <option value="12:00 PM">12:00 PM</option>
            <option value="1:00 PM">1:00 PM</option>
            <option value="2:00 PM">2:00 PM</option>
            <option value="3:00 PM">3:00 PM</option>
            <option value="4:00 PM">4:00 PM</option>
          </select>
        </div>
      </div>

      <div>
        <label className={labelClass}>{t.notes}</label>
        <textarea className={inputClass + " h-24 resize-none"} value={form.notes} onChange={e => set('notes', e.target.value)} placeholder={lang === 'es' ? 'Instrucciones especiales...' : 'Any special instructions...'} />
      </div>


      {error && (
        <p className="font-jost text-sm text-red-500 text-center">{error}</p>
      )}

      <button
        type="submit"
        disabled={loading}
        className="w-full gold-gradient text-white font-jost text-sm py-4 rounded-xl hover:opacity-90 transition-opacity shadow-lg disabled:opacity-60 disabled:cursor-not-allowed"
      >
        {loading
          ? (lang === 'es' ? 'Enviando...' : 'Sending...')
          : t.submit
        }
      </button>

      <p className="font-jost text-xs text-muted-foreground text-center italic">{t.disclaimer2}</p>
    </form>
  );
}