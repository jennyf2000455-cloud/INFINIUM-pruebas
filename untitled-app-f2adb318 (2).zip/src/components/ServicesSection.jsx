import React from 'react';
import { useLang } from './LanguageContext';

const services = [
  {
    icon: "🏠",
    en: { title: "Residential Cleaning", desc: "Regular, reliable cleaning for your home. We keep every corner spotless." },
    es: { title: "Limpieza Residencial", desc: "Limpieza regular y confiable para tu hogar. Cada rincón impecable." },
  },
  {
    icon: "✨",
    en: { title: "First-Time Deep Cleaning", desc: "A thorough, detailed clean for your first visit. We start fresh." },
    es: { title: "Limpieza Profunda Inicial", desc: "Una limpieza completa y detallada para tu primera visita." },
  },
  {
    icon: "📦",
    en: { title: "Move-In / Move-Out Cleaning", desc: "Starting fresh or leaving a great impression. We handle every detail." },
    es: { title: "Limpieza de Mudanza", desc: "Inicio perfecto o impresión final impecable. Nos encargamos de todo." },
  },
  {
    icon: "🏢",
    en: { title: "Commercial Cleaning", desc: "Professional cleaning for offices and small businesses in Virginia." },
    es: { title: "Limpieza Comercial", desc: "Limpieza profesional para oficinas y negocios en Virginia." },
  },
  {
    icon: "🍽️",
    en: { title: "Detailed Kitchen Cleaning", desc: "Deep clean of all kitchen surfaces, appliances, and high-touch areas." },
    es: { title: "Limpieza Detallada de Cocina", desc: "Limpieza profunda de superficies, electrodomésticos y áreas de contacto." },
  },
  {
    icon: "🚿",
    en: { title: "Bathroom Deep Cleaning", desc: "Sanitized, shining bathrooms from top to bottom. Tile, grout, fixtures." },
    es: { title: "Limpieza Profunda de Baños", desc: "Baños sanitizados y brillantes de arriba a abajo. Azulejos, lechada, accesorios." },
  },
  {
    icon: "🏠",
    en: { title: "Apartment Cleaning", desc: "Efficient, thorough cleaning designed for apartments of all sizes." },
    es: { title: "Limpieza de Apartamentos", desc: "Limpieza eficiente y completa para apartamentos de todos los tamaños." },
  },
  {
    icon: "⚙️",
    en: { title: "Custom Cleaning Services", desc: "Tailored to your specific needs. You decide, we deliver." },
    es: { title: "Servicios Personalizados", desc: "Adaptados a tus necesidades específicas. Tú decides, nosotros cumplimos." },
  },
];

export default function ServicesSection() {
  const { lang, t } = useLang();

  const scrollToIvy = () => {
    document.getElementById('ivy')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <p className="font-jost text-xs text-gold tracking-widest uppercase mb-3">What We Offer</p>
          <h2 className="font-cormorant text-4xl md:text-5xl font-semibold text-foreground mb-4">{t.servicesTitle}</h2>
          <p className="font-jost text-muted-foreground max-w-md mx-auto">{t.servicesSub}</p>
          <div className="w-16 h-px bg-gold mx-auto mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((s, i) => {
            const data = lang === 'es' ? s.es : s.en;
            return (
              <div key={i} className="group bg-ivory rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gold/0 hover:border-gold/20">
                <div className="text-3xl mb-4">{s.icon}</div>
                <h3 className="font-cormorant text-xl font-semibold text-foreground mb-2">{data.title}</h3>
                <p className="font-jost text-xs text-muted-foreground leading-relaxed mb-4">{data.desc}</p>
                <button
                  onClick={scrollToIvy}
                  className="font-jost text-xs text-gold border border-gold/40 px-4 py-2 rounded-full hover:bg-gold hover:text-white transition-all duration-200"
                >
                  {t.getEstimateBtn}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}